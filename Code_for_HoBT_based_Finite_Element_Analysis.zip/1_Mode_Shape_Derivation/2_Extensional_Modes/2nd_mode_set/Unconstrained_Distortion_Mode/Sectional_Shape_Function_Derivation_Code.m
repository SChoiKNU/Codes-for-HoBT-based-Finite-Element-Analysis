%% Sectional Shape Function of the 2nd-Order Unconstrained Distortion Mode C2 (Chi_2)

% Note that this code only considers extensional modes.

%  b:  width of the box beam section
%  h: height of the box beam section
% ss: s coordinate of the local coordinate system (z, n, s)

% Uz: Rigid-body translation along the z direction
% C1: 1st-order unconstrained distortion mode (Chi_1)
% W1: 1st-order warping mode

% psC2: s-directional shape function of C2
% psC2_j: psC2 for edge j (j=1, 2, 3, 4)
% pnC2: n-directional shape function of C2
% pnC2_j: pnC2 for edge j (j=1, 2, 3, 4)

%%
clearvars;
clc;
        
        syms b h ss

%% Load Sectional Shape Functions for modes Uz, C1, W1

        load Sec_Shape_Func_Uz.mat
        load Sec_Shape_Func_C1.mat
        load Sec_Shape_Func_W1.mat
        
%% Calculation of unknown coefficients (D1, C1, C2, C3, C4) included in psC2 (see Eq. (6.55))

% D1 = mat_C2s(1)
% C1 = C2 = C3 = C4 =0 (see Eq. (6.57))

% PSI_Uz: Indefinite integral of pzUz
        
        PSI_Uz_1(b, h, ss)=int(pzUz_1,ss);        PSI_Uz_2(b, h, ss)=int(pzUz_2,ss);
        PSI_Uz_3(b, h, ss)=int(pzUz_3,ss);        PSI_Uz_4(b, h, ss)=int(pzUz_4,ss);

% PSI_W1: Indefinite integral of pzW1

        PSI_W1_1(b, h, ss)=int(pzW1_1,ss);        PSI_W1_2(b, h, ss)=int(pzW1_2,ss);
        PSI_W1_3(b, h, ss)=int(pzW1_3,ss);        PSI_W1_4(b, h, ss)=int(pzW1_4,ss);
        
% Considering the orthogonality conditions defined in Eq. (6.56)

        mat_A =   int(psC1_1*(-PSI_Uz_1),ss,-h/2,h/2)+int(psC1_2*(-PSI_Uz_2),ss,-b/2,b/2);
        
        mat_B = -(int(psC1_1*(-PSI_W1_1),ss,-h/2,h/2)+int(psC1_2*(-PSI_W1_2),ss,-b/2,b/2));
        

% Determining the unknown coefficients
        
        mat_C2s=(mat_B)/(mat_A);


%% Closed-Form Expression of psC2 (see Eq. (4.85))

% A2_star: scaling constant of mode C2

        Coeff_C2=formula(mat_C2s);        
        
        A2_star=(h/20)*(1/(Coeff_C2*(-PSI_Uz_1(b, h, h/2))+(-PSI_W1_1(b, h, h/2))));

        psC2_1(b, h, ss)=A2_star*(Coeff_C2*(-PSI_Uz_1)+(-PSI_W1_1));        psC2_2(b, h, ss)=A2_star*(Coeff_C2*(-PSI_Uz_2)+(-PSI_W1_2));
        psC2_3(b, h, ss)=A2_star*(Coeff_C2*(-PSI_Uz_3)+(-PSI_W1_3));        psC2_4(b, h, ss)=A2_star*(Coeff_C2*(-PSI_Uz_4)+(-PSI_W1_4));


%% Calculation of unknown coefficients (C1,0 , C2,0 , C3,0 , C4,0) included in pnC2 (see Eq. (6.96))

% C1,0 = mat_C2n(1)
% C2,0 = mat_C2n(2)
% C3,0 = mat_C2n(1)
% C4,0 = mat_C2n(2) (see Eqs. (6.98b) and (6.98c))

% Determining the unknown coefficients (see Eqs. (6.98b) and (6.98c))
      
        pnC2_1(b, h, ss)= -psC2_2(b, h, (-b/2));        pnC2_2(b, h, ss)=  psC2_1(b, h,  (h/2));
        pnC2_3(b, h, ss)= -psC2_2(b, h, (-b/2));        pnC2_4(b, h, ss)=  psC2_1(b, h,  (h/2));


        save Sec_Shape_Func_C2.mat  psC2_1  psC2_2  psC2_3  psC2_4  pnC2_1  pnC2_2  pnC2_3  pnC2_4
        
        
        
        
        
        