function fval=PSI1(coef,e,s,d)
% e : current edge
% d : # of differencial

Nc=size(coef,1); % # of coefficient
Ns=length(s);

% row vectoring
if size(s,1)~=Ns
    s=s';
end

coef=dif(coef,d); % differencial

p=ones(Ns,1)*(0:Nc-1);
ss=s*ones(1,Nc);
sp=ss.^p;
fval=sp*coef(:,:,e);