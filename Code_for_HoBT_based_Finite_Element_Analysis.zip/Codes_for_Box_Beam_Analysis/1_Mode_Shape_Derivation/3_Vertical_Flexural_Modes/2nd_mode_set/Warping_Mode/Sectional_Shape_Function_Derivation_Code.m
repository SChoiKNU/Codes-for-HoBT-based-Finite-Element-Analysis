%% Sectional Shape Function of the 2nd-Order Warping Mode W2

% Note that this code only considers vertical flexural modes.

%  b:  width of the box beam section
%  h: height of the box beam section
% ss: s coordinate of the local coordinate system (z, n, s)

% Uy: Rigid-body vertical displacement
% Tx: Rigid-body vertical rotation
% C1: 1st-Order Unconstrained Distortion Mode
% W1: 1st-Order Unconstrained Warping Mode
% C2: 2nd-Order Unconstrained Distortion Mode

% pzW2: z-directional shape function of W2
% pzW2_j: pzW2 for edge j (j=1, 2, 3, 4)

%%
clearvars;
clc;
        
        syms b h ss

%% Load Sectional Shape Functions for modes Uy, Tx, C1, W1, C2

        load Sec_Shape_Func_Uy.mat
        load Sec_Shape_Func_Tx.mat
        load Sec_Shape_Func_C1.mat
        load Sec_Shape_Func_W1.mat
        load Sec_Shape_Func_C2.mat

%% Calculation of unknown coefficients (D1, D2, C2, C4) included in pzW2 (see Eq. (7.67))

% D1 = mat_W2z(1)
% D2 = mat_W2z(2)
% C2 = mat_W2z(3)
% C4 =-mat_W2z(3)
% C1=C3=0 (see Eq. (7.43))

% PSI_Uy: Indefinite integral of psUy
        
        PSI_Uy_1(b, h, ss)=int(psUy_1,ss);        PSI_Uy_2(b, h, ss)=int(psUy_2,ss);
        PSI_Uy_3(b, h, ss)=int(psUy_3,ss);        PSI_Uy_4(b, h, ss)=int(psUy_4,ss);

% PSI_C1: Indefinite integral of psC1
        
        PSI_C1_1(b, h, ss)=int(psC1_1,ss);        PSI_C1_2(b, h, ss)=int(psC1_2,ss);
        PSI_C1_3(b, h, ss)=int(psC1_3,ss);        PSI_C1_4(b, h, ss)=int(psC1_4,ss);

% PSI_C2: Indefinite integral of psC2

        PSI_C2_1(b, h, ss)=int(psC2_1,ss);        PSI_C2_2(b, h, ss)=int(psC2_2,ss);
        PSI_C2_3(b, h, ss)=int(psC2_3,ss);        PSI_C2_4(b, h, ss)=int(psC2_4,ss);


% Considering the conditions defined in Eqs. (7.44) and (7.68)
        
        mat_A = [(PSI_Uy_1(b, h, h/2)-PSI_Uy_2(b, h, -b/2))  (PSI_C1_1(b, h, h/2)-PSI_C1_2(b, h, -b/2))  -1;
                 int((pzTx_1)*(PSI_Uy_1),ss,-h/2,h/2)+int((pzTx_2)*(PSI_Uy_2),ss,-b/2,b/2)      int((pzTx_1)*(PSI_C1_1),ss,-h/2,h/2)+int((pzTx_2)*(PSI_C1_2),ss,-b/2,b/2)    int(pzTx_2,ss,-b/2,b/2);
                 int((pzW1_1)*(PSI_Uy_1),ss,-h/2,h/2)+int((pzW1_2)*(PSI_Uy_2),ss,-b/2,b/2)      int((pzW1_1)*(PSI_C1_1),ss,-h/2,h/2)+int((pzW1_2)*(PSI_C1_2),ss,-b/2,b/2)    int(pzW1_2,ss,-b/2,b/2)];
        
        mat_B = [-(PSI_C2_1(b, h, h/2)-PSI_C2_2(b, h, -b/2));
                 -(int((pzTx_1)*(PSI_C2_1),ss,-h/2,h/2)+int((pzTx_2)*(PSI_C2_2),ss,-b/2,b/2));
                 -(int((pzW1_1)*(PSI_C2_1),ss,-h/2,h/2)+int((pzW1_2)*(PSI_C2_2),ss,-b/2,b/2))];

% Determining the unknown coefficients
             
        mat_W2z=(mat_A)\(mat_B);


%% Closed-Form Expression of pzW2 (see Eq. (7.67))

% B2_star: scaling constant of mode W2

        Coeff_W2z=formula(mat_W2z);

        B2_star=(-2/100)/(Coeff_W2z(1)*(PSI_Uy_1(b, h, h/2))+Coeff_W2z(2)*(PSI_C1_1(b, h, h/2))+(PSI_C2_1(b, h, h/2)));

        pzW2_1(b, h, ss)= (B2_star)*(Coeff_W2z(1)*(PSI_Uy_1)+Coeff_W2z(2)*(PSI_C1_1)+(PSI_C2_1));        pzW2_2(b, h, ss)= (B2_star)*(Coeff_W2z(1)*(PSI_Uy_2)+Coeff_W2z(2)*(PSI_C1_2)+(PSI_C2_2)+Coeff_W2z(3));
        pzW2_3(b, h, ss)=-(B2_star)*(Coeff_W2z(1)*(PSI_Uy_1)+Coeff_W2z(2)*(PSI_C1_1)+(PSI_C2_1));        pzW2_4(b, h, ss)=-(B2_star)*(Coeff_W2z(1)*(PSI_Uy_2)+Coeff_W2z(2)*(PSI_C1_2)+(PSI_C2_2)+Coeff_W2z(3));


        save Sec_Shape_Func_W2.mat  pzW2_1  pzW2_2  pzW2_3  pzW2_4
        
        
        
        
        
        
        