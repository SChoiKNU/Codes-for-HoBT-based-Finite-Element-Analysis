%% HoBT Analysis for the numerical problem shown in Figure 6.8 (Part 2/2)

% this code only considers sectional modes shown under extension, especially Uz, C1, W1, C2, W2, C3, W3, C4, W4, C5, W5 (i.e., N1=5, N2=0)
% This code calculates the stresses sigma_zz, sigma_xx, and sigma_zx shown in Figures 6.8(d), 6.8(e), and  6.8(f)
% sigma_zz: normal stress along the z direction
% sigma_xx: normal stress along the x (or s) direction
% sigma_zx: shear stress

%%
clearvars;
clc;

%% Given Parameter Values
%  n: number of discretization
%  n_ele: number of elements that consist the box beam in Figure 6.8
%  n_nod: number of nodes involved in the box beam in Figure 6.8
%  b_val: value of the box beam section width
%  h_val: value of the box beam section height
%  t_val: value of the box beam section thickness
%  E: Young's modulus
%  v: Poisson's ratio
%  G: Shear modulus

load Field_variables_solution.mat
load B_matrix_b50_h75.mat

n=640;
n_ele=640;
n_nod=639;

b_val=0.05;     h_val=0.1;      t_val=0.002;

E=2*10^(11);    v=0.3;
E_1=E/(1-v^2);  G=E/(2*(1+v));

sigma_zz=zeros(n_nod-1,1);     
sigma_ss=zeros(n_nod-1,1);     
sigma_zs=zeros(n_nod-1,1);

% nod_z: z-directional coordinate

nod_z=zeros(n_nod-1,1);

for ii=1:(n_nod-1)
nod_z(ii)=(ii-0.5)*(100/(n_nod-1));
end


%% Calculate Stress Responses

% Measurement Points: Edge 2, s=b/8
%  ss: s coordinate of the local coordinate system (z, n, s)
% csy: z-directional natural coordinate (-1 <= csy <= 1)
% mat_B_2 is used to calculate stress on Edge 2 (see Eqs. (6.4) and (6.5))

ss=b_val/8;   csy=0;

mat_B_2 = matrix_B2(ss,csy);

for ii=1:(n_nod-1)
    
    mat_yy=[    yy_1(ii),    yy_2(ii),    yy_3(ii),    yy_4(ii),    yy_5(ii),    yy_6(ii),    yy_7(ii),    yy_8(ii),    yy_9(ii),   yy_10(ii),   yy_11(ii),...
              yy_1(ii+1),  yy_2(ii+1),  yy_3(ii+1),  yy_4(ii+1),  yy_5(ii+1),  yy_6(ii+1),  yy_7(ii+1),  yy_8(ii+1),  yy_9(ii+1), yy_10(ii+1), yy_11(ii+1)];

    strain_terms=mat_B_2*mat_yy';
                      
    sigma_zz(ii)=(E_1)*strain_terms(1)+(E_1*v)*strain_terms(2);
    sigma_ss(ii)=(E_1*v)*strain_terms(1)+(E_1)*strain_terms(2);
    sigma_zs(ii)=-(G)*strain_terms(3);
end

% Consider the positive directions of the s and x coordiantes
stress_zz= sigma_zz;
stress_xx=-sigma_ss;
stress_zx=-sigma_zs;


%% Plot the HoBT analysis results

figure(1);
plot(nod_z,stress_zz,'b','LineWidth',1.1);
hold on;

figure(2);
plot(nod_z,stress_xx,'b','LineWidth',1.1);
hold on;

figure(3);
plot(nod_z,stress_zx,'b','LineWidth',1.1);
hold on;


