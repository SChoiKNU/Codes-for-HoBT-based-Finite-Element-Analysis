function K=stiffness3(cnr,cnr_con,coef_s,coef_n,coef_z,prpt,Le)
% prpt : problem property

fprintf(1,'\n*** Stiffness matrix computation start ***\n');

% problem definition
t=prpt(1); % thickness
L=prpt(2); % length of the beam
E=prpt(3);
nu=prpt(4);

% problem property
[theta,a,Ledge]=pcoord(cnr,cnr_con);
Nedge=size(cnr_con,1); % # of edges
Nmode=size(coef_s,2)+size(coef_z,2);
Ndof=Nmode*2; % number of DOF / to use Hermite interpolation functions
if ~exist('Le','var')
    Nel=prpt(5); % number of element for each beam
    Le=L/Nel*ones(Nel,1); % length of each element
else
    Nel=length(Le);
end

% matrial property
E1=E/(1-nu^2);
D=E1*[1 nu 0;nu 1 0;0 0 (1-nu)/2];

% numerical property
tol=2;
degs=max(max([order(coef_s),order(coef_n),order(coef_z)]))*2; % maximum degree of polynomials
degz=3*2;

Ngps=ceil((degs+1)/2)+tol;
Ngpz=ceil((degz+1)/2)+tol;

[GPs,WFs]=LGQ(Ngps);
[GPz,WFz]=LGQ(Ngpz);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% BEAM STIFFNESS %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Hermite interpolation functions
N1=@(L,k) 1/4*(1-k)^2*(2+k);
N2=@(L,k) L/8*(1-k)^2*(1+k);
N3=@(L,k) 1/4*(1+k)^2*(2-k);
N4=@(L,k) L/8*(1+k)^2*(k-1);
dN1=@(L,k) ((k-1)^2/4+((2*k-2)*(k+2))/4)*2/L;
dN2=@(L,k) ((L*(k-1)^2)/8+(L*(2*k-2)*(k+1))/8)*2/L;
dN3=@(L,k) (-(k+1)^2/4-((2*k+2)*(k-2))/4)*2/L;
dN4=@(L,k) ((L*(k+1)^2)/8+(L*(2*k+2)*(k-1))/8)*2/L;
ddN1=@(L,k) (3*k)/2*(2/L)^2;
ddN2=@(L,k) ((L*(k+1))/4+(L*(2*k-2))/4)*(2/L)^2;
ddN3=@(L,k) (-(3*k)/2)*(2/L)^2;
ddN4=@(L,k) ((L*(k-1))/4+(L*(2*k+2))/4)*(2/L)^2;

N=@(L,k) [eye(Nmode)*N1(L,k),eye(Nmode)*N2(L,k),eye(Nmode)*N3(L,k),eye(Nmode)*N4(L,k)];
dN=@(L,k) [eye(Nmode)*dN1(L,k),eye(Nmode)*dN2(L,k),eye(Nmode)*dN3(L,k),eye(Nmode)*dN4(L,k)];
ddN=@(L,k) [eye(Nmode)*ddN1(L,k),eye(Nmode)*ddN2(L,k),eye(Nmode)*ddN3(L,k),eye(Nmode)*ddN4(L,k)];

% integral for stiffness
L1=[1 0 0;0 0 1];
L2=[0 1 0;0 0 0];
L3=[0 0 0;0 1 0];
L4=[1 0;0 0;0 1];
L5=[0 0;0 1;1 0];

La=L4*L1;
Lb=L5*L1;
Lc=L4*L2;
Ld=L4*L3+L5*L2;
Lf=L5*L3;

D1=La'*D*La;
D2=La'*D*Lb;
D3=Lb'*D*Lb;
D4=Lc'*D*Lc;
D5=Lc'*D*Ld;
D6=Ld'*D*Ld;
D7=Lc'*D*Lf;
D8=Ld'*D*Lf;
D9=Lf'*D*Lf;

H1=zeros(Nmode);
H2=H1;
H3=H1;
H4=H1;
H5=H1;
H6=H1;
H7=H1;
H8=H1;
H9=H1;

tt=t^3/12;
% s-integral
for i=1:Nedge % for i-th edge
    Ledg=Ledge(i);
    jcob=Ledg/2;    
    s=jcob*(GPs+1);
    
    F=PSI(coef_s,coef_n,coef_z,i,s,0);
    dF=PSI(coef_s,coef_n,coef_z,i,s,1);
    ddF=PSI(coef_s,coef_n,coef_z,i,s,2);
    
    for j=1:Ngps % for j-th point        
        wf=WFs(j);        
        
        f=F(:,:,j);
        df=dF(:,:,j);
        ddf=ddF(:,:,j);

        H1=H1+df'*D1*df*jcob*wf*t;
        H2=H2+df'*D2*f*jcob*wf*t;
        H3=H3+f'*D3*f*jcob*wf*t;
        H4=H4+ddf'*D4*ddf*jcob*wf*tt;
        H5=H5+ddf'*D5*df*jcob*wf*tt;
        H6=H6+df'*D6*df*jcob*wf*tt;
        H7=H7+ddf'*D7*f*jcob*wf*tt;
        H8=H8+df'*D8*f*jcob*wf*tt;
        H9=H9+f'*D9*f*jcob*wf*tt;
    end
end

% z-integral
L=intersect(Le,Le);
Ltype=zeros(Nel,1);
for m=1:length(L)
    % define type of length
    Lm=L(m);
    Ltype(Le==Lm)=m;    
    % local stiffness matrix
    k1=zeros(Ndof*2);
    k2=k1;
    k3=k1;
    k4=k1;
    k5=k1;
    k6=k1;
    k7=k1;
    k8=k1;
    k9=k1;

    jcob=Lm/2;
    for i=1:Ngpz % for j-th point
        ksi=GPz(i);
        wf=WFz(i);

        k1=k1+N(Lm,ksi)'*H1*N(Lm,ksi)*jcob*wf;
        k2=k2+N(Lm,ksi)'*H2*dN(Lm,ksi)*jcob*wf;
        k3=k3+dN(Lm,ksi)'*H3*dN(Lm,ksi)*jcob*wf;
        k4=k4+N(Lm,ksi)'*H4*N(Lm,ksi)*jcob*wf;
        k5=k5+N(Lm,ksi)'*H5*dN(Lm,ksi)*jcob*wf;
        k6=k6+dN(Lm,ksi)'*H6*dN(Lm,ksi)*jcob*wf;
        k7=k7+N(Lm,ksi)'*H7*ddN(Lm,ksi)*jcob*wf;
        k8=k8+dN(Lm,ksi)'*H8*ddN(Lm,ksi)*jcob*wf;
        k9=k9+ddN(Lm,ksi)'*H9*ddN(Lm,ksi)*jcob*wf;
    end
    ke(:,:,m)=k1+k2+k2'+k3+k4+k5+k5'+k6+k7+k7'+k8+k8'+k9;
end

K_all=zeros(2*Ndof*2*Ndof,Nel);
edofs=zeros(2*Ndof,Nel);
for i=1:Nel
    % element-dof connectivity
    edofs(:,i)=Ndof*(i-1)+1:Ndof*(i+1);
    % stiffness
    kei=ke(:,:,Ltype(i));
    K_all(:,i)=K_all(:,i)+kei(:);
end
indx_j=repmat(1:2*Ndof,2*Ndof,1);
indx_i=indx_j';
Ki=edofs(indx_i(:),:);
Kj=edofs(indx_j(:),:);
K=sparse(Ki,Kj,K_all);

fprintf(1,'\n*** Stiffness matrix computation complete ***\n');