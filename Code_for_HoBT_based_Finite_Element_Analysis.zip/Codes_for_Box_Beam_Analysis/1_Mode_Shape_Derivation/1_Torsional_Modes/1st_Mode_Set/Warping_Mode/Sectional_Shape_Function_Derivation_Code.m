%% Sectional Shape Function of the 1st-Order Warping Mode W1

% Note that this code only considers torsional modes.

%  b:  width of the box beam section
%  h: height of the box beam section
% ss: s coordinate of the local coordinate system (z, n, s)

% Tz: Rigid-body torsional rotation
% C0: Fundamental unconstrained distortion mode (Chi_0)
% W0: Fundamental warping mode

% pzW1: z-directional shape function of W1
% pzW1_j: pzW1 for edge j (j=1, 2, 3, 4)

%%
clearvars;
clc;
        
        syms b h ss

%% Load Sectional Shape Functions for modes Tz, C0, W0, C1 (see Eqs. (4.1), (4.2), (4.3), (4.40))
        
        load Sec_Shape_Func_Tz.mat
        load Sec_Shape_Func_C0.mat
        load Sec_Shape_Func_W0.mat
        load Sec_Shape_Func_C1.mat

%% Calculation of unknown coefficients (D1, D2) included in pzW1 (see Eq. (4.68))

% C1=C2=C3=C4=0 (see Eq. (4.72a, b))
% D1 = mat_W1z(1)
% D2 = mat_W1z(2)

% PSI_Tz: Indefinite integral of psTz
        
        PSI_Tz_1(b, h, ss)=int(psTz_1,ss);        PSI_Tz_2(b, h, ss)=int(psTz_2,ss);
        PSI_Tz_3(b, h, ss)=int(psTz_3,ss);        PSI_Tz_4(b, h, ss)=int(psTz_4,ss);
        
% PSI_C0: Indefinite integral of psC0

        PSI_C0_1(b, h, ss)=int(psC0_1,ss);        PSI_C0_2(b, h, ss)=int(psC0_2,ss);
        PSI_C0_3(b, h, ss)=int(psC0_3,ss);        PSI_C0_4(b, h, ss)=int(psC0_4,ss);
        
% PSI_C1: Indefinite integral of psC1
        
        PSI_C1_1(b, h, ss)=int(psC1_1,ss);        PSI_C1_2(b, h, ss)=int(psC1_2,ss);
        PSI_C1_3(b, h, ss)=int(psC1_3,ss);        PSI_C1_4(b, h, ss)=int(psC1_4,ss);


% Considering the conditions defined in Eqs. (4.70) and (4.71)

        mat_A=[                                 (PSI_C0_1(b, h, h/2)-PSI_C0_2(b, h, -b/2))                                    (PSI_C1_1(b, h, h/2)-PSI_C1_2(b, h, -b/2));
               (int((pzW0_1)*(PSI_C0_1),ss,-h/2,h/2)+int((pzW0_2)*(PSI_C0_2),ss,-b/2,b/2))   (int((pzW0_1)*(PSI_C1_1),ss,-h/2,h/2)+int((pzW0_2)*(PSI_C1_2),ss,-b/2,b/2))];
        
        mat_B=(b-h)*[                                 -(PSI_Tz_1(b, h, h/2)-PSI_Tz_2(b, h, -b/2));
                     -(int((pzW0_1)*(PSI_Tz_1),ss,-h/2,h/2)+int((pzW0_2)*(PSI_Tz_2),ss,-b/2,b/2))];
            
% Determining the unknown coefficients

        mat_W1z=(mat_A)\(mat_B);

        
%% Closed-Form Expression of pzW1 (see Eq. (4.68))

% B1_star: scaling constant of mode W1

        Coeff_W1z=formula(mat_W1z);

        B1_star=(2/100)/((b-h)*PSI_Tz_1(b, h, h/2)+Coeff_W1z(1)*(PSI_C0_1(b, h, h/2))+Coeff_W1z(2)*(PSI_C1_1(b, h, h/2)));

        pzW1_1(b, h, ss)= (B1_star)*((b-h)*PSI_Tz_1+Coeff_W1z(1)*(PSI_C0_1)+Coeff_W1z(2)*(PSI_C1_1));        pzW1_2(b, h, ss)= (B1_star)*((b-h)*PSI_Tz_2+Coeff_W1z(1)*(PSI_C0_2)+Coeff_W1z(2)*(PSI_C1_2));
        pzW1_3(b, h, ss)= (B1_star)*((b-h)*PSI_Tz_1+Coeff_W1z(1)*(PSI_C0_1)+Coeff_W1z(2)*(PSI_C1_1));        pzW1_4(b, h, ss)= (B1_star)*((b-h)*PSI_Tz_2+Coeff_W1z(1)*(PSI_C0_2)+Coeff_W1z(2)*(PSI_C1_2));


%% Save the resulting pzW1
                
        save Sec_Shape_Func_W1.mat  pzW1_1  pzW1_2  pzW1_3  pzW1_4
        
        
        


        