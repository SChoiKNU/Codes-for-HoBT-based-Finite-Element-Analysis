function modeshape(cnr,cnr_con,coef_s,coef_n,coef_z,m,scl)

% m : current mode
% if m=n+0.1, mode # start from warping mode

Ni=size(coef_s,2); % # of in-plane modes

% problem property
Ne=size(cnr_con,1); % # of the edges
[theta,a,L]=pcoord(cnr,cnr_con);
sc=scenter(cnr,cnr_con);
Np=ceil(L/min(L)*40); % # of point

% current mode
if m-floor(m)~=0
    m=floor(m)+Ni;
end

% mode type
if m>Ni
    mt=0; % out-of-plane mode
else
    mt=1; % in-plane mode
end

% cross section dimension
dim=max(max(cnr(:,1))-min(cnr(:,1)),max(cnr(:,2))-min(cnr(:,2)));

% transform matrix
T=@(a) [cos(a) sin(a) 0
    sin(a) -cos(a) 0
    0 0 1];

disp=[];
conf=[];
for i=1:Ne % for edge 'i'
    xi=cnr(cnr_con(i,1),1);
    yi=cnr(cnr_con(i,1),2);
    ai=a(i); % for coordinate transform
    Li=L(i);
    s=linspace(0,Li,Np(i));    

    fval=PSIm(coef_s,coef_n,coef_z,i,s,0,m);

    xc=xi+s*cos(ai);
    yc=yi+s*sin(ai);

    conf_i=[xc;yc;zeros(1,length(s))]; % configuration @ global coordinate
    disp_i=T(ai)*fval; % displacement @ global coordinate

    conf=[conf,conf_i];
    disp=[disp,disp_i];  
end

% plotting factor
if mt==0 % out-of-plane mode
    scl2=dim/6/max(max(abs(disp)))*scl;
    lw=4;
else % in-plane mode
    scl2=dim/7/max(max(abs(disp)))*scl;
    lw=4;
end
deformed=conf+disp*scl2;

% undeformed-sectional
hold on
for i=1:Ne
    rng=sum(Np(1:i-1))+1:sum(Np(1:i));    
    plot3(conf(3,rng),conf(1,rng),conf(2,rng),'k','LineWidth',lw)
end
% undeformed-axial
zcoord=[-max(L)/3.2
    -max(L)/3.2
    -max(L)/2
    -max(L)/2
    -max(L)/2
    -max(L)/2
    -max(L)/2
    -max(L)/1.6
    -max(L)/6.5
    -max(L)/2
    -max(L)/0.7
    -max(L)/3
    -max(L)/1.5];
for i=1:size(cnr,1)
    xcoord=cnr(i,1);
    ycoord=cnr(i,2);
%     plot3([0,zcoord(i)],xcoord*ones(1,2),ycoord*ones(1,2),'k','LineWidth',lw)
    plot3([0,zcoord(i)],xcoord*ones(1,2),ycoord*ones(1,2),'Color', [0.75 0.75 0.75],'LineWidth',lw)
end
% deformed
if scl~=0
    for i=1:Ne
        rng=sum(Np(1:i-1))+1:sum(Np(1:i));
        plot3(deformed(3,rng),deformed(1,rng),deformed(2,rng),'b','LineWidth',lw)
%         plot3(deformed(1,rng),deformed(2,rng),deformed(3,rng),'color',[0.5,0.5,0.9],'LineWidth',lw)
    end
end

% plot fitting
dim2=dim/6*1.5;
x=[min(zcoord),dim2];
y=[min(cnr(:,1))-dim2,max(cnr(:,1))+dim2];
z=[min(cnr(:,2))-dim2,max(cnr(:,2))+dim2];

axis equal off
axis([x,y,z])

if mt==0 % out-of-plane mode
    view([1 1 1])
%     view([1 -1 0.5])
else % in-plane mode
    view([1 0 0])
end