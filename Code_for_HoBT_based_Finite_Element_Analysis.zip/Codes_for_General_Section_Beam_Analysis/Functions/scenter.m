function [cnt,theta,r,d]=scenter(cnr,cnr_con)
% sc : coordinate of shear center
% r : sc to edge length
% d : s coordinate of s'
% s' : intersection of s and r

Ne=size(cnr_con,1);
[theta,a,L]=pcoord(cnr,cnr_con);

% part I - 'shear center'

A=0;
B=0;
C=0;
D=0;
E=0;
F=0;
for i=1:Ne % i-th edge
    % s-point @ global coord'
    X=cnr(cnr_con(i,1),1);
    Y=cnr(cnr_con(i,1),2);
    
    ai=a(i);
    bi=ai-theta;
    Li=L(i);
    
    A=A+Li*sin(ai)*cos(bi);
    B=B-Li*cos(ai)*cos(bi);
    C=C+Li*sin(ai)*sin(bi);
    D=D-Li*cos(ai)*sin(bi);
    E=E+Li*X*sin(ai)*cos(bi)-Li*Y*cos(ai)*cos(bi);
    F=F+Li*X*sin(ai)*sin(bi)-Li*Y*cos(ai)*sin(bi);
end

m=[A B
    C D];
u=[E
    F];
v=m\u;

cnt=v';

% part II - 'geometric chacteristics'

r=zeros(Ne,1);
d=zeros(Ne,1);
for i=1:Ne % i-th edge
    % s-point @ global coord'
    xs=cnr(cnr_con(i,1),1);
    ys=cnr(cnr_con(i,1),2);
    
    % shear center
    xc=cnt(1);
    yc=cnt(2);
    
    ai=a(i);
    
    r(i)=xs*sin(ai)-ys*cos(ai)-xc*sin(ai)+yc*cos(ai);
    d(i)=xc*cos(ai)+yc*sin(ai)-xs*cos(ai)-ys*sin(ai);
end