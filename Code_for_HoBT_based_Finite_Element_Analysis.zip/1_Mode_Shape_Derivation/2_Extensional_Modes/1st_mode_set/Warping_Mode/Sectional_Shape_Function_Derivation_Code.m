%% Sectional Shape Function of the 1st-Order Warping Mode W1

% Note that this code only considers extensional modes.

%  b:  width of the box beam section
%  h: height of the box beam section
% ss: s coordinate of the local coordinate system (z, n, s)

% Uz: Rigid-body translation along the z direction
% C1: 1st-order unconstrained distortion mode

% pzW1: z-directional shape function of W1
% pzW1_j: pzW1 for edge j (j=1, 2, 3, 4)

%%
clearvars;
clc;
        
        syms b h ss

%% Load Sectional Shape Functions for modes Uz, C1 (see Eqs. (6.3c))
        
        load Sec_Shape_Func_Uz.mat
        load Sec_Shape_Func_C1.mat

        
%% Calculation of unknown coefficients (C1, C2, C3, C4) included in pzW1 (see Eq. (6.35))

% C1 = mat_W1z(1)
% C2 = mat_W1z(2)
% C3 = mat_W1z(1)
% C4 = mat_W1z(2) (see Eq. (6.36))

% PSI_C1: Indefinite integral of psC1
                
        PSI_C1_1(b, h, ss)=int(psC1_1,ss);        PSI_C1_2(b, h, ss)=int(psC1_2,ss);
        PSI_C1_3(b, h, ss)=int(psC1_3,ss);        PSI_C1_4(b, h, ss)=int(psC1_4,ss);


% Considering the conditions defined in Eqs. (6.37) and (6.38)
        
        mat_A=[                         1                              -1;
                int((pzUz_1),ss,-h/2,h/2)       int((pzUz_2),ss,-b/2,b/2)];
                
        mat_B=[                            -(PSI_C1_1(b, h, h/2) - PSI_C1_2(b, h, -b/2));
                -(int((pzUz_1*PSI_C1_1),ss,-h/2,h/2)+int((pzUz_2*PSI_C1_2),ss,-b/2,b/2))];


% Determining the unknown coefficients
             
        mat_W1=(mat_A)\(mat_B);

        
%% Closed-Form Expression of pzW1 (see Eq. (6.35))

% B1_star: scaling constant of mode W1

        Coeff_W1=formula(mat_W1);        
        
        B1_star=((b+h)/5)*(1/(PSI_C1_1(b, h, h/2) - PSI_C1_1(b, h, 0)));
        
        pzW1_1(b, h, ss) = B1_star*(PSI_C1_1 + Coeff_W1(1));        pzW1_2(b, h, ss) = B1_star*(PSI_C1_2 + Coeff_W1(2));
        pzW1_3(b, h, ss) = B1_star*(PSI_C1_3 + Coeff_W1(1));        pzW1_4(b, h, ss) = B1_star*(PSI_C1_4 + Coeff_W1(2));

        
        save Sec_Shape_Func_W1.mat  pzW1_1  pzW1_2  pzW1_3  pzW1_4
        
        
        
        