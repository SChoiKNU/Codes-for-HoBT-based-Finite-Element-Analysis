%% Mass Matrix Calculation Code

% This code considers the numerical problem shown in Figure 7.13
% Thus, this code only considers vertical bending modes, especially Uy, Tx, C1, W1, C2, W2, C3, W3, N1_1, N1_2 (i.e., N1=3, N2=1)

%  ss: s coordinate of the local coordinate system (z, n, s)
%  nn: n coordinate of the local coordinate system (z, n, s)
% csy: z-directional natural coordinate (-1 <= csy <= 1)

% Uy: Rigid-body translation along the y direction (vertical displacement)
% Tx: Rigid-body rotation along the x direction (bending rotation)
% C1: 1st-order unconstrained distortion mode
% W1: 1st-order warping mode
% N1_1: 1st-order Type 1 constrained distortion mode
% N1_2: 1st-order Type 2 constrained distortion mode

% psC1: s-directional shape function of C1
% psC1_j: psC1 for edge j (j=1, 2, 3, 4)
% pnC1: n-directional shape function of C1
% pnC1_j: pnC1 for edge j (j=1, 2, 3, 4)
% -> The same notations are also used for other modes (e.g., Uy, Tx, C1, W1...).

%%
clearvars;
clc;

        syms ss nn csy


%% Given Parameter Values

%  b_val: value of the box beam section width
%  h_val: value of the box beam section height
%  t_val: value of the box beam section thickness
%  lo: Material density
%  L: Length of the box beam member
%  n: number of discretization
%  ele_L: Length of the box beam element

b_val=0.100;     
h_val=0.050;     
t_val=0.002;

lo=7850;

L=1;
n=160;

ele_L=L/n;

%% Define Sectional Shape Functions for the box beam with (b_val, h_val)

load Sec_Shape_Func_b100_h50.mat

    % Edge 1 Section-Shape Functions
        
        pnUy_1= 0;
        psUy_1= 1;
        pzUy_1= 0;
        
        pnTx_1= 0;
        psTx_1= 0;
        pzTx_1= ss;
        
        % membrane 1st set
        
        pnC1_1=given_pnC1_1;
        psC1_1=given_psC1_1;
        pzC1_1=0;

        pnW1_1=0;
        psW1_1=0;
        pzW1_1=given_pzW1_1;
        
        % membrane 2nd set
        
        pnC2_1=given_pnC2_1;
        psC2_1=given_psC2_1;
        pzC2_1=0;

        pnW2_1=0;
        psW2_1=0;
        pzW2_1=given_pzW2_1;
        
        % membrane 3rd set
        
        pnC3_1=given_pnC3_1;
        psC3_1=given_psC3_1;
        pzC3_1=0;

        pnW3_1=0;
        psW3_1=0;
        pzW3_1=given_pzW3_1;
        
        % edge-bending 1st set
        
        pnN1_1_1=given_pnN1_1_1;
        psN1_1_1=0;
        pzN1_1_1=0;
        
        pnN1_2_1=given_pnN1_2_1;
        psN1_2_1=0;
        pzN1_2_1=0;
        
        
    % Edge 2 Section-Shape Functions
        
        pnUy_2= 1;
        psUy_2= 0;
        pzUy_2= 0;
        
        pnTx_2= 0;
        psTx_2= 0;
        pzTx_2= (h_val/2+nn);
        
        % membrane 1st set
        
        pnC1_2=given_pnC1_2;
        psC1_2=given_psC1_2;
        pzC1_2=0;

        pnW1_2=0;
        psW1_2=0;
        pzW1_2=given_pzW1_2;
        
        % membrane 2nd set
        
        pnC2_2=given_pnC2_2;
        psC2_2=given_psC2_2;
        pzC2_2=0;

        pnW2_2=0;
        psW2_2=0;
        pzW2_2=given_pzW2_2;
        
        % membrane 3rd set
        
        pnC3_2=given_pnC3_2;
        psC3_2=given_psC3_2;
        pzC3_2=0;

        pnW3_2=0;
        psW3_2=0;
        pzW3_2=given_pzW3_2;
        
        % edge-bending 1st set
        
        pnN1_1_2=given_pnN1_1_2;
        psN1_1_2=0;
        pzN1_1_2=0;
        
        pnN1_2_2=given_pnN1_2_2;
        psN1_2_2=0;
        pzN1_2_2=0;
        
        
    % Edge 3 Section-Shape Functions
        
        pnUy_3= 0;
        psUy_3=-1;
        pzUy_3= 0;
        
        pnTx_3= 0;
        psTx_3= 0;
        pzTx_3=-ss;
        
        % membrane 1st set
        
        pnC1_3=given_pnC1_3;
        psC1_3=given_psC1_3;
        pzC1_3=0;

        pnW1_3=0;
        psW1_3=0;
        pzW1_3=given_pzW1_3;
        
        % membrane 2nd set
        
        pnC2_3=given_pnC2_3;
        psC2_3=given_psC2_3;
        pzC2_3=0;

        pnW2_3=0;
        psW2_3=0;
        pzW2_3=given_pzW2_3;
        
        % membrane 3rd set
        
        pnC3_3=given_pnC3_3;
        psC3_3=given_psC3_3;
        pzC3_3=0;

        pnW3_3=0;
        psW3_3=0;
        pzW3_3=given_pzW3_3;
        
        % edge-bending 1st set
        
        pnN1_1_3=given_pnN1_1_3;
        psN1_1_3=0;
        pzN1_1_3=0;
        
        pnN1_2_3=given_pnN1_2_3;
        psN1_2_3=0;
        pzN1_2_3=0;
        
        
    % Edge 4 Section-Shape Functions
        
        pnUy_4=-1;
        psUy_4= 0;
        pzUy_4= 0;
        
        pnTx_4= 0;
        psTx_4= 0;
        pzTx_4=-(h_val/2+nn);
        
        % membrane 1st set
        
        pnC1_4=given_pnC1_4;
        psC1_4=given_psC1_4;
        pzC1_4=0;

        pnW1_4=0;
        psW1_4=0;
        pzW1_4=given_pzW1_4;
        
        % membrane 2nd set
        
        pnC2_4=given_pnC2_4;
        psC2_4=given_psC2_4;
        pzC2_4=0;

        pnW2_4=0;
        psW2_4=0;
        pzW2_4=given_pzW2_4;
        
        % membrane 3rd set
        
        pnC3_4=given_pnC3_4;
        psC3_4=given_psC3_4;
        pzC3_4=0;

        pnW3_4=0;
        psW3_4=0;
        pzW3_4=given_pzW3_4;
        
        % edge-bending 1st set
        
        pnN1_1_4=given_pnN1_1_4;
        psN1_1_4=0;
        pzN1_1_4=0;
        
        pnN1_2_4=given_pnN1_2_4;
        psN1_2_4=0;
        pzN1_2_4=0;
        

%% Define Interpolation Functions
% Linear interpolation functions:  (1-csy)/2, (1+csy)/2
% Hermite interpolation functions: (1/4)*(1-csy)^2*(2+csy),(ele_L/8)*(1-csy)^2*(1+csy), (1/4)*(1+csy)^2*(2-csy), (ele_L/8)*(1+csy)^2*(csy-1)
% Kinematic variables per node: {Uy, Tx, C1, W1, C1', C2, W2, C2', C3, W3, C3', N1_1, N1_2, N1_1', N1_2'}
% C1', C2', C3', N1_1', N1_2': z-directional derivatives of C1, C2, C3, N1_1, and N1_2
        
        mat_H=[(1-csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0 0;
               0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0;
               0 0 (1/4)*(1-csy)^2*(2+csy) 0 (ele_L/8)*(1-csy)^2*(1+csy) 0 0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1+csy)^2*(2-csy) 0 (ele_L/8)*(1+csy)^2*(csy-1) 0 0 0 0 0 0 0 0 0 0;
               0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0 0 0 0 0 0 0;
               0 0 0 0 0 (1/4)*(1-csy)^2*(2+csy) 0 (ele_L/8)*(1-csy)^2*(1+csy) 0 0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1+csy)^2*(2-csy) 0 (ele_L/8)*(1+csy)^2*(csy-1) 0 0 0 0 0 0 0;
               0 0 0 0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0 0 0 0;
               0 0 0 0 0 0 0 0 (1/4)*(1-csy)^2*(2+csy) 0 (ele_L/8)*(1-csy)^2*(1+csy) 0 0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1+csy)^2*(2-csy) 0 (ele_L/8)*(1+csy)^2*(csy-1) 0 0 0 0;
               0 0 0 0 0 0 0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0;
               0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1-csy)^2*(2+csy) 0 (ele_L/8)*(1-csy)^2*(1+csy) 0 0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1+csy)^2*(2-csy) 0 (ele_L/8)*(1+csy)^2*(csy-1) 0;
               0 0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1-csy)^2*(2+csy) 0 (ele_L/8)*(1-csy)^2*(1+csy) 0 0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1+csy)^2*(2-csy) 0 (ele_L/8)*(1+csy)^2*(csy-1)];
           

%% Define Displacement Field (see Eqs. (7.2), (7.75), (7.78), and (7.79))        
% dis_n_j: n-directional displacement at edge j (j=1, 2, 3, 4)
% dis_s_j: s-directional displacement at edge j (j=1, 2, 3, 4)
% dis_z_j: z-directional displacement at edge j (j=1, 2, 3, 4)
% Note that dis_n_j_prime (j=1, 2, 3, 4) is introduced to satisfy Eqs. (7.78) and (7.79).

        dis_n_1=[pnUy_1 pnTx_1 pnC1vb_1 pnW1vb_1 pnC2vb_1 pnW2vb_1 pnC3vb_1 pnW3vb_1 pnN1_1vb_1 pnN1_2vb_1]*mat_H;
  dis_n_1_prime=[     0 pnTx_1 pnC1vb_1 pnW1vb_1 pnC2vb_1 pnW2vb_1 pnC3vb_1 pnW3vb_1 pnN1_1vb_1 pnN1_2vb_1]*mat_H;
        dis_s_1=[psUy_1 psTx_1 psC1vb_1 psW1vb_1 psC2vb_1 psW2vb_1 psC3vb_1 psW3vb_1 psN1_1vb_1 psN1_2vb_1]*mat_H -nn*diff(dis_n_1_prime,ss);
        dis_z_1=[pzUy_1 pzTx_1 pzC1vb_1 pzW1vb_1 pzC2vb_1 pzW2vb_1 pzC3vb_1 pzW3vb_1 pzN1_1vb_1 pzN1_2vb_1]*mat_H -nn*diff(dis_n_1_prime,csy)*(2/ele_L);

        dis_n_2=[pnUy_2 pnTx_2 pnC1vb_2 pnW1vb_2 pnC2vb_2 pnW2vb_2 pnC3vb_2 pnW3vb_2 pnN1_1vb_2 pnN1_2vb_2]*mat_H;
  dis_n_2_prime=[     0 pnTx_2 pnC1vb_2 pnW1vb_2 pnC2vb_2 pnW2vb_2 pnC3vb_2 pnW3vb_2 pnN1_1vb_2 pnN1_2vb_2]*mat_H;
        dis_s_2=[psUy_2 psTx_2 psC1vb_2 psW1vb_2 psC2vb_2 psW2vb_2 psC3vb_2 psW3vb_2 psN1_1vb_2 psN1_2vb_2]*mat_H -nn*diff(dis_n_2_prime,ss);
        dis_z_2=[pzUy_2 pzTx_2 pzC1vb_2 pzW1vb_2 pzC2vb_2 pzW2vb_2 pzC3vb_2 pzW3vb_2 pzN1_1vb_2 pzN1_2vb_2]*mat_H -nn*diff(dis_n_2_prime,csy)*(2/ele_L);
        
        dis_n_3=[pnUy_3 pnTx_3 pnC1vb_3 pnW1vb_3 pnC2vb_3 pnW2vb_3 pnC3vb_3 pnW3vb_3 pnN1_1vb_3 pnN1_2vb_3]*mat_H;
  dis_n_3_prime=[     0 pnTx_3 pnC1vb_3 pnW1vb_3 pnC2vb_3 pnW2vb_3 pnC3vb_3 pnW3vb_3 pnN1_1vb_3 pnN1_2vb_3]*mat_H;
        dis_s_3=[psUy_3 psTx_3 psC1vb_3 psW1vb_3 psC2vb_3 psW2vb_3 psC3vb_3 psW3vb_3 psN1_1vb_3 psN1_2vb_3]*mat_H -nn*diff(dis_n_3_prime,ss);
        dis_z_3=[pzUy_3 pzTx_3 pzC1vb_3 pzW1vb_3 pzC2vb_3 pzW2vb_3 pzC3vb_3 pzW3vb_3 pzN1_1vb_3 pzN1_2vb_3]*mat_H -nn*diff(dis_n_3_prime,csy)*(2/ele_L);
        
        dis_n_4=[pnUy_4 pnTx_4 pnC1vb_4 pnW1vb_4 pnC2vb_4 pnW2vb_4 pnC3vb_4 pnW3vb_4 pnN1_1vb_4 pnN1_2vb_4]*mat_H;
  dis_n_4_prime=[     0 pnTx_4 pnC1vb_4 pnW1vb_4 pnC2vb_4 pnW2vb_4 pnC3vb_4 pnW3vb_4 pnN1_1vb_4 pnN1_2vb_4]*mat_H;
        dis_s_4=[psUy_4 psTx_4 psC1vb_4 psW1vb_4 psC2vb_4 psW2vb_4 psC3vb_4 psW3vb_4 psN1_1vb_4 psN1_2vb_4]*mat_H -nn*diff(dis_n_4_prime,ss);
        dis_z_4=[pzUy_4 pzTx_4 pzC1vb_4 pzW1vb_4 pzC2vb_4 pzW2vb_4 pzC3vb_4 pzW3vb_4 pzN1_1vb_4 pzN1_2vb_4]*mat_H -nn*diff(dis_n_4_prime,csy)*(2/ele_L);
        
        
%% Calculate Mass Matrix (see Eqs. (3.31), (3.32), and (3.33))       
% mat_M_j: local mass matrix M calculated at edge j (j=1, 2, 3, 4)

        mat_B_1=[dis_n_1;
                 dis_s_1;
                 dis_z_1];
                            
        mat_B_2=[dis_n_2;
                 dis_s_2;
                 dis_z_2];
               
        mat_B_3=[dis_n_3;
                 dis_s_3;
                 dis_z_3];
        
        mat_B_4=[dis_n_4;
                 dis_s_4;
                 dis_z_4];

               
        mat_M_1=lo*(mat_B_1'*mat_B_1);

        mat_M_2=lo*(mat_B_2'*mat_B_2);
  
        mat_M_3=lo*(mat_B_3'*mat_B_3);
        
        mat_M_4=lo*(mat_B_4'*mat_B_4);

        
        mat_M_13=mat_M_1+mat_M_3;

        mat_M_24=mat_M_2+mat_M_4;

          
% Volume integration to obtain the element mass matrix (see Eq. (3.33)) 
          
        local_M_13=zeros(30,30);
        local_M_24=zeros(30,30);
        
        
        for ii=1:30
            for jj=1:30
                local_M_13(ii,jj)=int(int(int(mat_M_13(ii,jj),ss,-(h_val/2),(h_val/2)),nn,-(t_val/2),t_val/2),csy,-1,1)*(ele_L/2);
            end
        end
        
        for ii=1:30
            for jj=1:30
                local_M_24(ii,jj)=int(int(int(mat_M_24(ii,jj),ss,-(b_val/2),(b_val/2)),nn,-(t_val/2),t_val/2),csy,-1,1)*(ele_L/2);
            end
        end        

        
% local_M: The resulting element mass matrix

        local_M=local_M_13+local_M_24;
        
        save M_matrix_b100_h50.mat local_M
        


        