%% Sectional Shape Function of the 1st-Order Type 1 Constraint Distortion Mode N1_1

% Note that this code only considers extensional modes.

%  b:  width of the box beam section
%  h: height of the box beam section
% ss: s coordinate of the local coordinate system (z, n, s)

% pnN1_1: n-directional shape function of N1_1
% pnN1_1_j: pnN1_1 for edge j (j=1, 2, 3, 4)

%%
clearvars;
clc;
        
        syms b h ss

%% Calculation of unknown coefficients (C1, C2, D1, D2, D3) included in pnN1_1 (see Eq. (6.119))

% C1 = mat_N1_1(1)
% C2 = mat_N1_1(2)
% D1 = mat_N1_1(3)
% D2 = mat_N1_1(4)
% D3 = mat_N1_1(5)

% Considering the conditions defined in Eq. (6.117)

        mat_A = [      1      (h/2)^2         0             0                   0;
                       0            0         1      (-b/2)^2            (-b/2)^4;
                       0            h         0             0                   0;       
                       0            0         0      2*(-b/2)        (4)*(-b/2)^3;
                       0            2         0          (-2)      (-12)*(-b/2)^2];

        mat_B = [        -(h/2)^4;
                                0;
                     (-4)*(h/2)^3;
                                0;
                    (-12)*(h/2)^2];
  
        
% Determining the unknown coefficients

        mat_N1_1=(mat_A)\(mat_B);

        
%% Closed-Form Expression of pnN1_1 (see Eq. (6.119))

% C1_star: scaling constant of mode N1_1

        Coeff_N1_1=formula(mat_N1_1);
        
        C1_star=(b/5)*(1/Coeff_N1_1(1));

        pnN1_1_1(b, h, ss) =  C1_star*(Coeff_N1_1(1)+Coeff_N1_1(2)*(ss)^2+(ss)^4);        pnN1_1_2(b, h, ss) =  C1_star*(Coeff_N1_1(3)+Coeff_N1_1(4)*(ss)^2+Coeff_N1_1(5)*(ss)^4);
        pnN1_1_3(b, h, ss) =  C1_star*(Coeff_N1_1(1)+Coeff_N1_1(2)*(ss)^2+(ss)^4);        pnN1_1_4(b, h, ss) =  C1_star*(Coeff_N1_1(3)+Coeff_N1_1(4)*(ss)^2+Coeff_N1_1(5)*(ss)^4);


%% Save the resulting pnN1_1
                
        save Sec_Shape_Func_N1_1.mat  pnN1_1_1  pnN1_1_2  pnN1_1_3  pnN1_1_4


        
        
        