%% Stiffness Matrix Calculation Code

% This code considers the numerical problem shown in Figure 5.5
% Thus, this code only considers torsional modes, especially Tz, C0, W0, C1, W1 (i.e., N1=1, N2=0)

%  ss: s coordinate of the local coordinate system (z, n, s)
%  nn: n coordinate of the local coordinate system (z, n, s)
% csy: z-directional natural coordinate (-1 <= csy <= 1)

% Tz: Rigid-body torsional rotation
% C0: Fundamental unconstrained distortion mode
% W0: Fundamental warping mode
% C1: 1st-order unconstrained distortion mode
% W1: 1st-order warping mode

% psC1: s-directional shape function of C1
% psC1_j: psC1 for edge j (j=1, 2, 3, 4)
% pnC1: n-directional shape function of C1
% pnC1_j: pnC1 for edge j (j=1, 2, 3, 4)
% -> The same notations are also used for other modes (e.g., Tz, C0, W0...).

%%
clearvars;
clc;

        syms ss nn csy
      
%% Given Parameter Values

%  b_val: value of the box beam section width
%  h_val: value of the box beam section height
%  t_val: value of the box beam section thickness
%  E: Young's modulus
%  v: Poisson's ratio
%  G: Shear modulus
%  L: Length of the box beam member
%  n: number of discretization
%  ele_L: Length of the box beam element

b_val=0.050;     
h_val=0.075;     
t_val=0.002;

E=200*10^(9);
v=0.3;
E_1=E/(1-v^2);
G=E/(2*(1+v));

L=1;
n=160;

ele_L=L/n;

%% Define Sectional Shape Functions for the box beam with (b_val, h_val)
% pnC0_j_prime: Linearized part of the pnC0 at edge j (j=1, 2, 3, 4)

load Sec_Shape_Func_b50_h75.mat

    % Edge 1 Section-Shape Functions
        
        pnTz_1= -ss;
        psTz_1= b_val/2;
        pzTz_1= 0;
        
        pnC0_1= given_pnC0_1;
        pnC0_1_prime= ((2*b_val)/(b_val+h_val))*(ss);
        psC0_1= given_psC0_1;
        pzC0_1= 0;
        
        pnW0_1= 0;
        psW0_1= 0;
        pzW0_1= given_pzW0_1;
        
        pnC1_1=given_pnC1_1;
        psC1_1=given_psC1_1;
        pzC1_1=0;

        pnW1_1=0;
        psW1_1=0;
        pzW1_1=given_pzW1_1;
        
    % Edge 2 Section-Shape Functions
        
        pnTz_2= -ss;
        psTz_2= h_val/2;
        pzTz_2= 0;
        
        pnC0_2= given_pnC0_2;
        pnC0_2_prime=-((2*h_val)/(b_val+h_val))*(ss);
        psC0_2= given_psC0_2;
        pzC0_2= 0;
        
        pnW0_2= 0;
        psW0_2= 0;
        pzW0_2= given_pzW0_2;
        
        pnC1_2=given_pnC1_2;
        psC1_2=given_psC1_2;
        pzC1_2=0;

        pnW1_2=0;
        psW1_2=0;
        pzW1_2=given_pzW1_2;
        
    % Edge 3 Section-Shape Functions
        
        pnTz_3= -ss;
        psTz_3= b_val/2;
        pzTz_3= 0;
        
        pnC0_3= given_pnC0_3;
        pnC0_3_prime= ((2*b_val)/(b_val+h_val))*(ss);
        psC0_3= given_psC0_3;
        pzC0_3= 0;
        
        pnW0_3= 0;
        psW0_3= 0;
        pzW0_3= given_pzW0_3;
        
        pnC1_3=given_pnC1_3;
        psC1_3=given_psC1_3;
        pzC1_3=0;

        pnW1_3=0;
        psW1_3=0;
        pzW1_3=given_pzW1_3;
        
    % Edge 4 Section-Shape Functions
        
        pnTz_4= -ss;
        psTz_4= h_val/2;
        pzTz_4= 0;
        
        pnC0_4= given_pnC0_4;
        pnC0_4_prime=-((2*h_val)/(b_val+h_val))*(ss);
        psC0_4= given_psC0_4;
        pzC0_4= 0;
        
        pnW0_4= 0;
        psW0_4= 0;
        pzW0_4= given_pzW0_4;
        
        pnC1_4=given_pnC1_4;
        psC1_4=given_psC1_4;
        pzC1_4=0;

        pnW1_4=0;
        psW1_4=0;
        pzW1_4=given_pzW1_4;


%% Define Interpolation Functions
% Linear interpolation functions:  (1-csy)/2, (1+csy)/2
% Hermite interpolation functions: (1/4)*(1-csy)^2*(2+csy),(ele_L/8)*(1-csy)^2*(1+csy), (1/4)*(1+csy)^2*(2-csy), (ele_L/8)*(1+csy)^2*(csy-1)
% Kinematic variables per node: {Tz, C0, W0, Tz', C0', C1, W1, C1'}
% Tz', C0', C1': z-directional derivatives of Tz, C0, and C1

% mat_H: Interpolation Function Matrix N (see Eq. (3.21))
        
        mat_H=[(1/4)*(1-csy)^2*(2+csy) 0 0 (ele_L/8)*(1-csy)^2*(1+csy) 0 0 0 0 (1/4)*(1+csy)^2*(2-csy) 0 0 (ele_L/8)*(1+csy)^2*(csy-1) 0 0 0 0;
               0 (1/4)*(1-csy)^2*(2+csy) 0 0 (ele_L/8)*(1-csy)^2*(1+csy) 0 0 0 0 (1/4)*(1+csy)^2*(2-csy) 0 0 (ele_L/8)*(1+csy)^2*(csy-1) 0 0 0;
               0 0 (1-csy)/2 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0;
               0 0 0 0 0 (1/4)*(1-csy)^2*(2+csy) 0 (ele_L/8)*(1-csy)^2*(1+csy) 0 0 0 0 0 (1/4)*(1+csy)^2*(2-csy) 0 (ele_L/8)*(1+csy)^2*(csy-1);
               0 0 0 0 0 0 (1-csy)/2 0 0 0 0 0 0 0 (1+csy)/2 0];

%% Define Displacement Field (see Eqs. (4.5), (5.1), and (5.2))        
% dis_n_j: n-directional displacement at edge j (j=1, 2, 3, 4)
% dis_s_j: s-directional displacement at edge j (j=1, 2, 3, 4)
% dis_z_j: z-directional displacement at edge j (j=1, 2, 3, 4)
% dis_n_j_2, dis_s_j_2, dis_z_j_2: pnC0_j_prime is considered.

        dis_n_1=[pnTz_1 pnC0_1 pnW0_1 pnC1_1 pnW1_1]*mat_H;
        dis_s_1=[psTz_1 psC0_1 psW0_1 psC1_1 psW1_1]*mat_H -nn*diff(dis_n_1,ss);
        dis_z_1=[pzTz_1 pzC0_1 pzW0_1 pzC1_1 pzW1_1]*mat_H -nn*diff(dis_n_1,csy)*(2/ele_L);

        dis_n_1_2=[pnTz_1 pnC0_1_prime pnW0_1 pnC1_1 pnW1_1]*mat_H;
        dis_s_1_2=[psTz_1 psC0_1       psW0_1 psC1_1 psW1_1]*mat_H -nn*diff(dis_n_1_2,ss);
        dis_z_1_2=[pzTz_1 pzC0_1       pzW0_1 pzC1_1 pzW1_1]*mat_H -nn*diff(dis_n_1_2,csy)*(2/ele_L);

        dis_n_2=[pnTz_2 pnC0_2 pnW0_2 pnC1_2 pnW1_2]*mat_H;
        dis_s_2=[psTz_2 psC0_2 psW0_2 psC1_2 psW1_2]*mat_H -nn*diff(dis_n_2,ss);
        dis_z_2=[pzTz_2 pzC0_2 pzW0_2 pzC1_2 pzW1_2]*mat_H -nn*diff(dis_n_2,csy)*(2/ele_L);

        dis_n_2_2=[pnTz_2 pnC0_2_prime pnW0_2 pnC1_2 pnW1_2]*mat_H;
        dis_s_2_2=[psTz_2 psC0_2       psW0_2 psC1_2 psW1_2]*mat_H -nn*diff(dis_n_2_2,ss);
        dis_z_2_2=[pzTz_2 pzC0_2       pzW0_2 pzC1_2 pzW1_2]*mat_H -nn*diff(dis_n_2_2,csy)*(2/ele_L);

        dis_n_3=[pnTz_3 pnC0_3 pnW0_3 pnC1_3 pnW1_3]*mat_H;
        dis_s_3=[psTz_3 psC0_3 psW0_3 psC1_3 psW1_3]*mat_H -nn*diff(dis_n_3,ss);
        dis_z_3=[pzTz_3 pzC0_3 pzW0_3 pzC1_3 pzW1_3]*mat_H -nn*diff(dis_n_3,csy)*(2/ele_L);

        dis_n_3_2=[pnTz_3 pnC0_3_prime pnW0_3 pnC1_3 pnW1_3]*mat_H;
        dis_s_3_2=[psTz_3 psC0_3       psW0_3 psC1_3 psW1_3]*mat_H -nn*diff(dis_n_3_2,ss);
        dis_z_3_2=[pzTz_3 pzC0_3       pzW0_3 pzC1_3 pzW1_3]*mat_H -nn*diff(dis_n_3_2,csy)*(2/ele_L);

        dis_n_4=[pnTz_4 pnC0_4 pnW0_4 pnC1_4 pnW1_4]*mat_H;
        dis_s_4=[psTz_4 psC0_4 psW0_4 psC1_4 psW1_4]*mat_H -nn*diff(dis_n_4,ss);
        dis_z_4=[pzTz_4 pzC0_4 pzW0_4 pzC1_4 pzW1_4]*mat_H -nn*diff(dis_n_4,csy)*(2/ele_L);

        dis_n_4_2=[pnTz_4 pnC0_4_prime pnW0_4 pnC1_4 pnW1_4]*mat_H;
        dis_s_4_2=[psTz_4 psC0_4       psW0_4 psC1_4 psW1_4]*mat_H -nn*diff(dis_n_4_2,ss);
        dis_z_4_2=[pzTz_4 pzC0_4       pzW0_4 pzC1_4 pzW1_4]*mat_H -nn*diff(dis_n_4_2,csy)*(2/ele_L);

%% Define Strain Field (see Eqs. (4.10) and (5.3))        
% str_zz_j: z-directional normal strain at edge j (j=1, 2, 3, 4)
% str_ss_j: s-directional normal strain at edge j (j=1, 2, 3, 4)
% str_sz_j: shear strain at edge j (j=1, 2, 3, 4)

        str_zz_1=diff(dis_z_1,csy)*(2/ele_L);
        str_ss_1=diff(dis_s_1,ss);
        str_sz_1=diff(dis_z_1_2,ss)+diff(dis_s_1_2,csy)*(2/ele_L);

        str_zz_2=diff(dis_z_2,csy)*(2/ele_L);
        str_ss_2=diff(dis_s_2,ss);
        str_sz_2=diff(dis_z_2_2,ss)+diff(dis_s_2_2,csy)*(2/ele_L);

        str_zz_3=diff(dis_z_3,csy)*(2/ele_L);
        str_ss_3=diff(dis_s_3,ss);
        str_sz_3=diff(dis_z_3_2,ss)+diff(dis_s_3_2,csy)*(2/ele_L);

        str_zz_4=diff(dis_z_4,csy)*(2/ele_L);
        str_ss_4=diff(dis_s_4,ss);
        str_sz_4=diff(dis_z_4_2,ss)+diff(dis_s_4_2,csy)*(2/ele_L);

%% Define Constitutive Relations (see Eqs. (4.11) and (5.5))

        mat_C=[E_1      E_1*v    0;
               E_1*v    E_1      0;
               0        0        G];

%% Calculate Stiffness Matrix (see Eqs. (3.24), (4.12), and (5.7))       
% mat_K_j: local stiffness matrix K calculated at edge j (j=1, 2, 3, 4)

        mat_B_1=[str_zz_1;
                 str_ss_1;
                 str_sz_1];
                            
        mat_B_2=[str_zz_2;
                 str_ss_2;
                 str_sz_2];
               
        mat_B_3=[str_zz_3;
                 str_ss_3;
                 str_sz_3];
        
        mat_B_4=[str_zz_4;
                 str_ss_4;
                 str_sz_4];

               
        mat_K_1=(mat_B_1)'*mat_C*mat_B_1;

        mat_K_2=(mat_B_2)'*mat_C*mat_B_2;
  
        mat_K_3=(mat_B_3)'*mat_C*mat_B_3;
        
        mat_K_4=(mat_B_4)'*mat_C*mat_B_4;

        
        mat_K_13=mat_K_1+mat_K_3;

        mat_K_24=mat_K_2+mat_K_4;


% Volume integration to obtain the element stiffness matrix (see Eq. (3.27)) 
          
        local_K_13=zeros(16,16);
        local_K_24=zeros(16,16);

        for ii=1:16
            for jj=1:16
                local_K_13(ii,jj)=int(int(int(mat_K_13(ii,jj),ss,-(h_val/2),(h_val/2)),nn,-(t_val/2),t_val/2),csy,-1,1)*(ele_L/2);
            end
        end
        
        for ii=1:16
            for jj=1:16
                local_K_24(ii,jj)=int(int(int(mat_K_24(ii,jj),ss,-(b_val/2),(b_val/2)),nn,-(t_val/2),t_val/2),csy,-1,1)*(ele_L/2);
            end
        end        

% local_K: The resulting element stiffness matrix

        local_K=local_K_13+local_K_24;
        
        save K_matrix_b50_h75.mat local_K
        


        