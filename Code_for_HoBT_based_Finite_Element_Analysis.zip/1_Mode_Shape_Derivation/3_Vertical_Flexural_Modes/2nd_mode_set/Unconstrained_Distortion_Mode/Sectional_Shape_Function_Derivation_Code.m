%% Sectional Shape Function of the 2nd-Order Unconstrained Distortion Mode C2 (Chi_2)

% Note that this code only considers vertical flexural modes.

%  b:  width of the box beam section
%  h: height of the box beam section
% ss: s coordinate of the local coordinate system (z, n, s)

% Uy: Rigid-body vertical displacement
% Tx: Rigid-body vertical rotation
% C1: 1st-Order Unconstrained Distortion Mode
% W1: 1st-Order Unconstrained Warping Mode

% psC2: s-directional shape function of C2
% psC2_j: psC2 for edge j (j=1, 2, 3, 4)
% pnC2: n-directional shape function of C2
% pnC2_j: pnC2 for edge j (j=1, 2, 3, 4)

%%
clearvars;
clc;
        
        syms b h ss

%% Load Sectional Shape Functions for modes Uy, Tx, C1, W1

        load Sec_Shape_Func_Uy.mat
        load Sec_Shape_Func_Tx.mat
        load Sec_Shape_Func_C1.mat
        load Sec_Shape_Func_W1.mat

%% Calculation of unknown coefficients (D1, C1, C3) included in psC2 (see Eq. (7.59))

% D1 = mat_C2s(1)
% C1 = mat_C2s(2)
% C3 =-mat_C2s(2)
% C2 = C4 = 0 (see Eq. (7.61))

% PSI_Tx: Indefinite integral of pzTx
        
        PSI_Tx_1(b, h, ss)=int(pzTx_1,ss);        PSI_Tx_2(b, h, ss)=int(pzTx_2,ss);
        PSI_Tx_3(b, h, ss)=int(pzTx_3,ss);        PSI_Tx_4(b, h, ss)=int(pzTx_4,ss);

% PSI_W1: Indefinite integral of pzW1

        PSI_W1_1(b, h, ss)=int(pzW1_1,ss);        PSI_W1_2(b, h, ss)=int(pzW1_2,ss);
        PSI_W1_3(b, h, ss)=int(pzW1_3,ss);        PSI_W1_4(b, h, ss)=int(pzW1_4,ss);
 
% Considering the orthogonality conditions defined in Eq. (7.60)
        
        mat_A = [   int((-PSI_Tx_1)*(psUy_1),ss,-h/2,h/2)+int((-PSI_Tx_2)*(psUy_2),ss,-b/2,b/2)         int((psUy_1),ss,-h/2,h/2);
                    int((-PSI_Tx_1)*(psC1_1),ss,-h/2,h/2)+int((-PSI_Tx_2)*(psC1_2),ss,-b/2,b/2)         int((psC1_1),ss,-h/2,h/2)];

        mat_B = [  -(int((-PSI_W1_1)*(psUy_1),ss,-h/2,h/2)+int((-PSI_W1_2)*(psUy_2),ss,-b/2,b/2));
                   -(int((-PSI_W1_1)*(psC1_1),ss,-h/2,h/2)+int((-PSI_W1_2)*(psC1_2),ss,-b/2,b/2))];

% Determining the unknown coefficients

        mat_C2s=(mat_A)\(mat_B);


%% Closed-Form Expression of psC2 (see Eq. (7.59))

% A2_star: scaling constant of mode C2
        
        Coeff_C2s=formula(mat_C2s);
        
        A2_star=(-1/100)/(Coeff_C2s(1)*(-PSI_Tx_2(b, h, -b/2))+(-PSI_W1_2(b, h, -b/2)));
        
        psC2_1(b, h, ss)= A2_star*(Coeff_C2s(1)*(-PSI_Tx_1)+(-PSI_W1_1)+Coeff_C2s(2));        psC2_2(b, h, ss)= A2_star*(Coeff_C2s(1)*(-PSI_Tx_2)+(-PSI_W1_2));
        psC2_3(b, h, ss)=-A2_star*(Coeff_C2s(1)*(-PSI_Tx_1)+(-PSI_W1_1)+Coeff_C2s(2));        psC2_4(b, h, ss)=-A2_star*(Coeff_C2s(1)*(-PSI_Tx_2)+(-PSI_W1_2));

%% Calculation of unknown coefficients (C1,1 , C2,0 , C3,1 , C4,0) included in pnC2 (see Eq. (7.106))

% C1,1 = mat_C2n(1)
% C2,0 = mat_C2n(2)
% C3,1 =-mat_C2n(1)
% C4,0 =-mat_C2n(2) (see Eqs. (7.109a) and (7.109b))
% C1,0 = C2,1 = C3,0 = C4,1 = 0 (see Eq. (7.109c))

% Considering the displacement continuity conditions defined in Eq. (7.108c)
        
        A21_star=A2_star*Coeff_C2s(1);
        
        mat_A= [ (h/2)  0;
                    0   1];
            
        mat_B= [ -(psC2_2(b, h, -b/2))/A21_star;
                  (psC2_1(b, h,  h/2))/A21_star-(1/2)*(-b/2)^2];

% Determining the unknown coefficients
              
        mat_C2n=(mat_A)\(mat_B);
        

%% Closed-Form Expression of pnC1 (see Eq. (7.106))
                
        Coeff_C2n=formula(mat_C2n);
        
        pnC2_1(b, h, ss)= A21_star*(Coeff_C2n(1)*(ss));        pnC2_2(b, h, ss)= A21_star*(Coeff_C2n(2)+(1/2)*(ss)^2);
        pnC2_3(b, h, ss)=-A21_star*(Coeff_C2n(1)*(ss));        pnC2_4(b, h, ss)=-A21_star*(Coeff_C2n(2)+(1/2)*(ss)^2);

        save Sec_Shape_Func_C2.mat psC2_1  psC2_2  psC2_3  psC2_4  pnC2_1  pnC2_2  pnC2_3  pnC2_4

 
        
        
        