%% HoBT Analysis for the numerical problem shown in Figure 6.8 (Part 1/2)

% this code only considers sectional modes shown under extension, especially Uz, C1, W1, C2, W2, C3, W3, C4, W4, C5, W5 (i.e., N1=5, N2=0)
% This code calculates the stresses sigma_zz, sigma_xx, and sigma_zx shown in Figures 6.8(d), 6.8(e), and  6.8(f)
% sigma_zz: normal stress along the z direction
% sigma_xx: normal stress along the x (or s) direction
% sigma_zx: shear stress

%%
clearvars;
clc;

%% Given Parameter Values
%  n: number of discretization
%  n_ele: number of elements that consist the box beam in Figure 6.8
%  n_nod: number of nodes involved in the box beam in Figure 6.8
% nod_dis: number of nodal kinematic variables per node (i.e.,  {Uz, C1, W1, C2, W2, C3, W3, C4, W4, C5, W5})
% glo_dis: number of total nodal kinematic variables
% glo_frc: number of total nodal forces
% mat_glo_K: global stiffness matrix K
% mat_glo_dis: global nodal displacement vector
% mat_glo_frc: global nodal force vector

load K_matrix_b50_h75.mat

n=640;
n_ele=640;
n_nod=641;

nod_dis=11;

glo_dis=nod_dis*n_nod;
glo_frc=glo_dis;

mat_glo_K=zeros(glo_dis,glo_dis);
mat_glo_dis=zeros(glo_dis,1);
mat_glo_frc=zeros(glo_frc,1);

% apply the external axial force Fz=100 N at the end B (see Figure 6.8)
mat_glo_frc(nod_dis*(n_nod-1)+1,1)=100;

% yy_i: resulting vlaue of the ith kinematic variable along the axial direction
% yy_1: Uz, yy_2: C1, yy_3: W1, yy_4: C2, yy_5: W2, yy_6: C3, yy_7: W3, yy_8: C4, yy_9: W4, yy_10: C5, yy_11: W5

 yy_1=zeros(n_nod-2,1);
 yy_2=zeros(n_nod-2,1);    yy_3=zeros(n_nod-2,1);
 yy_4=zeros(n_nod-2,1);    yy_5=zeros(n_nod-2,1);
 yy_6=zeros(n_nod-2,1);    yy_7=zeros(n_nod-2,1);
 yy_8=zeros(n_nod-2,1);    yy_9=zeros(n_nod-2,1);
 yy_10=zeros(n_nod-2,1);  yy_11=zeros(n_nod-2,1);


%% Calculate Global Stiffness Matrix

for ii=1:1:(n_nod-1)
    mat_glo_K((nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis),(nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis))=mat_glo_K((nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis),(nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis))+local_K_extension;
end


%% Apply Boundary Conditions at Both Ends A and B

disp_BC=[(nod_dis+1):(nod_dis*(n_nod-1)+1)];

%% Solve the Finite Element Equations

mat_glo_dis(disp_BC,1)=mat_glo_K(disp_BC,disp_BC)\mat_glo_frc(disp_BC,1);


%% Obtained Field Variables Solution

for ii=2:1:(n_nod-1)
     yy_1(ii-1)=mat_glo_dis(nod_dis*(ii-1)+1);
     yy_2(ii-1)=mat_glo_dis(nod_dis*(ii-1)+2);     yy_3(ii-1)=mat_glo_dis(nod_dis*(ii-1)+3);
     yy_4(ii-1)=mat_glo_dis(nod_dis*(ii-1)+4);     yy_5(ii-1)=mat_glo_dis(nod_dis*(ii-1)+5);
     yy_6(ii-1)=mat_glo_dis(nod_dis*(ii-1)+6);     yy_7(ii-1)=mat_glo_dis(nod_dis*(ii-1)+7);
     yy_8(ii-1)=mat_glo_dis(nod_dis*(ii-1)+8);     yy_9(ii-1)=mat_glo_dis(nod_dis*(ii-1)+9);
    yy_10(ii-1)=mat_glo_dis(nod_dis*(ii-1)+10);   yy_11(ii-1)=mat_glo_dis(nod_dis*(ii-1)+11);
end


save Field_variables_solution.mat  yy_1   yy_2   yy_3   yy_4   yy_5   yy_6   yy_7   yy_8   yy_9  yy_10  yy_11





