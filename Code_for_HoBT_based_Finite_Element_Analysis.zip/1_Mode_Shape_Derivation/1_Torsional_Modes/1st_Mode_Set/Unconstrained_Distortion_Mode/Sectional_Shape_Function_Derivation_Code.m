%% Sectional Shape Function of the 1st-Order Unconstrained Distortion Mode C1 (Chi_1)

% Note that this code only considers torsional modes.

%  b:  width of the box beam section
%  h: height of the box beam section
% ss: s coordinate of the local coordinate system (z, n, s)

% Tz: Rigid-body torsional rotation
% C0: Fundamental unconstrained distortion mode (Chi_0)
% W0: Fundamental warping mode

% psC1: s-directional shape function of C1
% psC1_j: psC1 for edge j (j=1, 2, 3, 4)
% pnC1: n-directional shape function of C1
% pnC1_j: pnC1 for edge j (j=1, 2, 3, 4)
% -> The same notations are also used for other modes (i.e., Tz, C0, W0).

%%
clearvars;
clc;
        
        syms b h ss

%% Load Sectional Shape Functions for modes Tz, C0, W0 (see Eqs. (4.1), (4.2), (4.3))

        load Sec_Shape_Func_Tz.mat
        load Sec_Shape_Func_C0.mat
        load Sec_Shape_Func_W0.mat
        
%% Calculation of unknown coefficients (C1, C2, C3, C4) included in psC1 (see Eq. (4.40))

% C1 = mat_C1s(1)
% C2 = mat_C1s(2)
% C3 = mat_C1s(1)
% C4 = mat_C1s(2) (see Eq. (4.43))

% PSI_W0: Indefinite integral of pzW0
        
        PSI_W0_1(b, h, ss)=int(pzW0_1,ss);        PSI_W0_2(b, h, ss)=int(pzW0_2,ss);
        PSI_W0_3(b, h, ss)=int(pzW0_3,ss);        PSI_W0_4(b, h, ss)=int(pzW0_4,ss);

% Considering the orthogonality conditions defined in Eq. (4.44)

        mat_A = [int(psTz_1,ss,-h/2,h/2)  int(psTz_2,ss,-b/2,b/2);
                 int(psC0_1,ss,-h/2,h/2)  int(psC0_2,ss,-b/2,b/2)];

        mat_B = [-int((psTz_1)*(-PSI_W0_1),ss,-h/2,h/2)-int((psTz_2)*(-PSI_W0_2),ss,-b/2,b/2);
                 -int((psC0_1)*(-PSI_W0_1),ss,-h/2,h/2)-int((psC0_2)*(-PSI_W0_2),ss,-b/2,b/2)];

% Determining the unknown coefficients

        mat_C1s=(mat_A)\(mat_B);
        
        
%% Closed-Form Expression of psC1 (see Eq. (4.40))

% A1_star: scaling constant of mode C1

        Coeff_C1s=formula(mat_C1s);
        
        A1_star=(1/100)/((-PSI_W0_1(b, h, h/2))+Coeff_C1s(1));
        
        psC1_1(b, h, ss)= A1_star*((-PSI_W0_1)+Coeff_C1s(1));        psC1_2(b, h, ss)= A1_star*((-PSI_W0_2)+Coeff_C1s(2));
        psC1_3(b, h, ss)= A1_star*((-PSI_W0_1)+Coeff_C1s(1));        psC1_4(b, h, ss)= A1_star*((-PSI_W0_2)+Coeff_C1s(2));

%% Calculation of unknown coefficients (C1,1 , C2,1 , C3,1 , C4,1) included in pnC1 (see Eq. (5.33))

% C1,1 = mat_C1n(1)
% C2,1 = mat_C1n(2)
% C3,1 = mat_C1n(1)
% C4,1 = mat_C1n(2) (see Eqs. (5.37a) and (5.37b))

% Considering the displacement continuity conditions defined in Eq. (5.36c)
        
        mat_A= [ (h/2)       0;
                    0   (-b/2)];

        mat_B= [ -(1/6)*(h/2)^3-(1/A1_star)*psC1_2(b, h, -b/2);
                 (1/6)*(-b/2)^3+(1/A1_star)*psC1_1(b, h, h/2)];
              
% Determining the unknown coefficients

        mat_C1n=(mat_A)\(mat_B);


%% Closed-Form Expression of pnC1 (see Eq. (5.33))
        
        Coeff_C1n=formula(mat_C1n);
        
        pnC1_1(b, h, ss)= A1_star*( (1/6)*(ss)^3+Coeff_C1n(1)*(ss));        pnC1_2(b, h, ss)= A1_star*(-(1/6)*(ss)^3+Coeff_C1n(2)*(ss));
        pnC1_3(b, h, ss)= A1_star*( (1/6)*(ss)^3+Coeff_C1n(1)*(ss));        pnC1_4(b, h, ss)= A1_star*(-(1/6)*(ss)^3+Coeff_C1n(2)*(ss));


%% Save the resulting psC1 and pnC1
                
        save Sec_Shape_Func_C1.mat psC1_1  psC1_2  psC1_3  psC1_4  pnC1_1  pnC1_2  pnC1_3  pnC1_4



