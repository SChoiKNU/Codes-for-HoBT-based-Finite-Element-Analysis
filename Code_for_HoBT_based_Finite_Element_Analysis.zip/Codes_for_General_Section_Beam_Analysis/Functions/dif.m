function coef=dif(coef,n)
% This function returns differenciated form of shape functions.
% n : # of differentials

if ~exist('n','var')
    n=1;
end

Ne=size(coef,3); % # of edges
Nm=size(coef,2); % # of modes
Nc=size(coef,1); % # of coefficient

% row shifting function
    function m2=shift(m1)        
        row=size(m1,1);
        col=size(m1,2);
        r1=2:row;        
        m2=[m1(r1,:)
            zeros(1,col)];
    end

cc=(0:Nc-1)'*ones(1,Nm);
for i=1:n
    for e=1:Ne
        ci=coef(:,:,e).*cc;
        coef(:,:,e)=shift(ci);
    end
end

end