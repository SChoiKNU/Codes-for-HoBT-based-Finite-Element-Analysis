%% Sectional Shape Function of the 1st-Order Type 2 Constraint Distortion Mode N1_2

% Note that this code only considers extensional modes.

%  b:  width of the box beam section
%  h: height of the box beam section
% ss: s coordinate of the local coordinate system (z, n, s)

% pnN1_2: n-directional shape function of N1_2
% pnN1_2_j: pnN1_2 for edge j (j=1, 2, 3, 4)

%%
clearvars;
clc;
        
        syms b h ss

%% Load Sectional Shape Function for mode N1_1

        load Sec_Shape_Func_N1_1.mat


%% Calculation of unknown coefficients (C1, C2, D1, D2, D3) included in pnN1_2 (see Eq. (6.121))

% C1 = mat_N1_1(1)
% C2 = mat_N1_1(2)
% D1 = mat_N1_1(3)
% D2 = mat_N1_1(4)
% D3 = mat_N1_1(5)

% DIF_N1_1: derivative of pnN1_1
        
        DIF_N1_1_1=diff(pnN1_1_1,ss);        DIF_N1_1_2=diff(pnN1_1_2,ss);
        DIF_N1_1_3=diff(pnN1_1_3,ss);        DIF_N1_1_4=diff(pnN1_1_4,ss);

% Considering the conditions defined in Eq. (6.122)
        
        mat_A = [      1                                      (h/2)^2        0                                            0                                              0;
                       0                                            0        1                                     (-b/2)^2                                       (-b/2)^4;
                       0                                            h        0                                    -2*(-b/2)                                  -(4)*(-b/2)^3;
                       0                                            2        0                                         (-2)                                 (-12)*(-b/2)^2;
                       0         int((2*ss)*(DIF_N1_1_1),ss,-h/2,h/2)        0         int((2*ss)*(DIF_N1_1_2),ss,-b/2,b/2)         int((4*ss^3)*(DIF_N1_1_2),ss,-b/2,b/2)];
   
                
        mat_B = [                                   -(h/2)^4;
                                                           0;
                                                (-4)*(h/2)^3;
                                               (-12)*(h/2)^2;
                     -int((4*ss^3)*(DIF_N1_1_1),ss,-h/2,h/2)];
  
% Determining the unknown coefficients
        
        mat_N1_2=(mat_A)\(mat_B);

        
%% Closed-Form Expression of pnN1_2 (see Eq. (6.121))

% C1_til_star: scaling constant of mode N1_2

        Coeff_N1_2=formula(mat_N1_2);
        
        C1_til_star=-(b/5)*(1/Coeff_N1_2(1));

        pnN1_2_1(b, h, ss) =  C1_til_star*(Coeff_N1_2(1)+Coeff_N1_2(2)*(ss)^2+(ss)^4);        pnN1_2_2(b, h, ss) =  C1_til_star*(Coeff_N1_2(3)+Coeff_N1_2(4)*(ss)^2+Coeff_N1_2(5)*(ss)^4);
        pnN1_2_3(b, h, ss) =  C1_til_star*(Coeff_N1_2(1)+Coeff_N1_2(2)*(ss)^2+(ss)^4);        pnN1_2_4(b, h, ss) =  C1_til_star*(Coeff_N1_2(3)+Coeff_N1_2(4)*(ss)^2+Coeff_N1_2(5)*(ss)^4);
        

%% Save the resulting pnN1_2
        
        save Sec_Shape_Func_N1_2.mat  pnN1_2_1  pnN1_2_2  pnN1_2_3  pnN1_2_4


        
        
        