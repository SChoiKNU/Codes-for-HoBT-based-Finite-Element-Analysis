%% Sectional Deformation Shape of the 1st-Order Type 2 Constrained Distortion Mode N1_2

%%
clearvars;
clc;

%% Box Beam Section Dimensions

% b_val: given value of the width b
% h_val: given value of the height h

    b_val=0.05;    h_val=0.1;

%% Load Sectional Shape Function of N1_2
    
    syms b h ss
        
    load Sec_Shape_Func_N1_2.mat
    
%% Matrices Used to Define Undeformed/Deformed Location of Edge j (j=1, 2, 3, 4)

% scale_fac: scale factor
% nod_leng: element length used to discretize edge j
% nod_numj: number of nodes (nodes: ends of the element) involved in edge j
% Edgej_loc_x: x-directional undeformed location of edge j
% Edgej_deformed_x: x-directional deformed location of edge j


    scale_fac=0.5;
    nod_leng=0.001;
    
    nod_num1=h_val/nod_leng+1;    nod_num2=b_val/nod_leng+1;
    nod_num3=h_val/nod_leng+1;    nod_num4=b_val/nod_leng+1;
    
    
    Edge1_loc_x=zeros(nod_num1,1);         Edge1_loc_y=zeros(nod_num1,1);
    Edge1_deformed_x=zeros(nod_num1,1);    Edge1_deformed_y=zeros(nod_num1,1);

    Edge2_loc_x=zeros(nod_num2,1);         Edge2_loc_y=zeros(nod_num2,1);
    Edge2_deformed_x=zeros(nod_num2,1);    Edge2_deformed_y=zeros(nod_num2,1);

    Edge3_loc_x=zeros(nod_num3,1);         Edge3_loc_y=zeros(nod_num3,1);
    Edge3_deformed_x=zeros(nod_num3,1);    Edge3_deformed_y=zeros(nod_num3,1);
    
    Edge4_loc_x=zeros(nod_num4,1);         Edge4_loc_y=zeros(nod_num4,1);
    Edge4_deformed_x=zeros(nod_num4,1);    Edge4_deformed_y=zeros(nod_num4,1);

    
%% Define Undeformed/Deformed Location of Edge j (j=1, 2, 3, 4)

% Edge 1
% ss1: s coordinate of edge 1

    for ii=1:nod_num1
        ss1=(-h_val/2)+(ii-1)/(nod_num1-1)*(h_val);
        
        Edge1_loc_x(ii)=b_val/2;        Edge1_loc_y(ii)=ss1;
        Edge1_deformed_x(ii)=Edge1_loc_x(ii)+(scale_fac)*(pnN1_2_1(b_val, h_val, ss1));
        Edge1_deformed_y(ii)=Edge1_loc_y(ii);
    end
    
% Edge 2
% ss2: s coordinate of edge 2

    for ii=1:nod_num2
        ss2=(-b_val/2)+(ii-1)/(nod_num2-1)*(b_val);
        
        Edge2_loc_x(ii)=-ss2;        Edge2_loc_y(ii)=h_val/2;
        Edge2_deformed_x(ii)=Edge2_loc_x(ii);
        Edge2_deformed_y(ii)=Edge2_loc_y(ii)+(scale_fac)*(pnN1_2_2(b_val, h_val, ss2));
    end
    
% Edge 3
% ss3: s coordinate of edge 3

    for ii=1:nod_num3
        ss3=(-h_val/2)+(ii-1)/(nod_num3-1)*(h_val);
        
        Edge3_loc_x(ii)=-b_val/2;        Edge3_loc_y(ii)=-ss3;
        Edge3_deformed_x(ii)=Edge3_loc_x(ii)-(scale_fac)*(pnN1_2_3(b_val, h_val, ss3));
        Edge3_deformed_y(ii)=Edge3_loc_y(ii);
    end
    
% Edge 4
% ss4: s coordinate of edge 4

    for ii=1:nod_num4
        ss4=(-b_val/2)+(ii-1)/(nod_num4-1)*(b_val);
        
        Edge4_loc_x(ii)=ss4;        Edge4_loc_y(ii)=-h_val/2;
        Edge4_deformed_x(ii)=Edge4_loc_x(ii);
        Edge4_deformed_y(ii)=Edge4_loc_y(ii)-(scale_fac)*(pnN1_2_4(b_val, h_val, ss4));
    end

    
%% Sectional Deformation Shape Plot
    
    figure(1);
    
    plot(Edge1_loc_x,Edge1_loc_y,'k','lineWidth',1.1);    hold on;
    plot(Edge2_loc_x,Edge2_loc_y,'k','lineWidth',1.1);    hold on;
    plot(Edge3_loc_x,Edge3_loc_y,'k','lineWidth',1.1);    hold on;
    plot(Edge4_loc_x,Edge4_loc_y,'k','lineWidth',1.1);    hold on;

    plot(Edge1_deformed_x,Edge1_deformed_y,'b','lineWidth',1.1);    hold on;
    plot(Edge2_deformed_x,Edge2_deformed_y,'b','lineWidth',1.1);    hold on;
    plot(Edge3_deformed_x,Edge3_deformed_y,'b','lineWidth',1.1);    hold on;
    plot(Edge4_deformed_x,Edge4_deformed_y,'b','lineWidth',1.1);    hold on;

    axis([-0.075 0.075 -0.075 0.075]);
        
    
    
    