%% Sectional Shape Function of the 1st-Order Unconstrained Distortion Mode C1 (Chi_1)

% Note that this code only considers vertical flexural modes.

%  b:  width of the box beam section
%  h: height of the box beam section
% ss: s coordinate of the local coordinate system (z, n, s)

% Uy: Rigid-body vertical displacement
% Tx: Rigid-body vertical rotation

% psC1: s-directional shape function of C1
% psC1_j: psC1 for edge j (j=1, 2, 3, 4)
% pnC1: n-directional shape function of C1
% pnC1_j: pnC1 for edge j (j=1, 2, 3, 4)
% -> The same notations are also used for other modes (i.e., Uy, Tx).

%%
clearvars;
clc;
        
        syms b h ss

%% Load Sectional Shape Functions for modes Uy, Tx (see Eqs. (7.3a), (7.3b))

        load Sec_Shape_Func_Uy.mat
        load Sec_Shape_Func_Tx.mat
        
%% Calculation of unknown coefficients (C1, C2, C3, C4) included in psC1 (see Eq. (7.25))

% C1 =  mat_C1s(1)
% C2 =  0
% C3 = -mat_C1s(1)
% C4 =  0 (see Eq. (7.27a), (7.27b), (7.27c))

% PSI_Uy: Indefinite integral of pzUy
        
        PSI_Uy_1(b, h, ss)=int(psUy_1,ss);        PSI_Uy_2(b, h, ss)=int(psUy_2,ss);
        PSI_Uy_3(b, h, ss)=int(psUy_3,ss);        PSI_Uy_4(b, h, ss)=int(psUy_4,ss);

% PSI_Tx: Indefinite integral of pzTx

        PSI_Tx_1(b, h, ss)=int(pzTx_1,ss);        PSI_Tx_2(b, h, ss)=int(pzTx_2,ss);
        PSI_Tx_3(b, h, ss)=int(pzTx_3,ss);        PSI_Tx_4(b, h, ss)=int(pzTx_4,ss);

% Considering the orthogonality conditions defined in Eq. (7.28)

        mat_A =  int(psUy_1,ss,-h/2,h/2);
        mat_B = -int((psUy_1)*(-PSI_Tx_1),ss,-h/2,h/2);

% Determining the unknown coefficients

        mat_C1s=(mat_B)/(mat_A);


%% Closed-Form Expression of psC1 (see Eq. (7.25))

% A1_star: scaling constant of mode C1
        
        Coeff_C1s=formula(mat_C1s);
        
        A1_star=(-1/100)/(-PSI_Tx_2(b, h, -b/2));
        
        psC1_1(b, h, ss)=A1_star*(-PSI_Tx_1+Coeff_C1s(1));        psC1_2(b, h, ss)=A1_star*(-PSI_Tx_2);
        psC1_3(b, h, ss)=A1_star*(-PSI_Tx_3-Coeff_C1s(1));        psC1_4(b, h, ss)=A1_star*(-PSI_Tx_4);

%% Calculation of unknown coefficients (C1,1 , C2,0 , C3,1 , C4,0) included in pnC1 (see Eq. (7.106))

% C1,1 = mat_C1n(1)
% C2,0 = mat_C1n(2)
% C3,1 =-mat_C1n(1)
% C4,0 =-mat_C1n(2) (see Eqs. (7.109a) and (7.109b))
% C1,0 = C2,1 = C3,0 = C4,1 = 0 (see Eq. (7.109c))

% Considering the displacement continuity conditions defined in Eq. (7.108c)
                
        mat_A= [ (h/2)  0;
                    0   1];
            
        mat_B= [ -(psC1_2(b, h, -b/2))/A1_star;
                  (psC1_1(b, h,  h/2))/A1_star-(1/2)*(-b/2)^2];

% Determining the unknown coefficients
              
        mat_C1n=(mat_A)\(mat_B);


%% Closed-Form Expression of pnC1 (see Eq. (7.106))
                
        Coeff_C1n=formula(mat_C1n);
        
        pnC1_1(b, h, ss)= A1_star*(Coeff_C1n(1)*(ss));        pnC1_2(b, h, ss)= A1_star*(Coeff_C1n(2)+(1/2)*(ss)^2);
        pnC1_3(b, h, ss)=-A1_star*(Coeff_C1n(1)*(ss));        pnC1_4(b, h, ss)=-A1_star*(Coeff_C1n(2)+(1/2)*(ss)^2);


%% Save the resulting psC1 and pnC1
                
        save Sec_Shape_Func_C1.mat psC1_1  psC1_2  psC1_3  psC1_4  pnC1_1  pnC1_2  pnC1_3  pnC1_4

 
        
        
        