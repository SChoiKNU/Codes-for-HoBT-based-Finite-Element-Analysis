function fval=PSI(coef_s,coef_n,coef_z,e,s,d)

Nm_i=size(coef_s,2); % # of in-plane modes
Nm_o=size(coef_z,2); % # of out-of-plane modes

fs=PSI1(coef_s,e,s,d);
fn=PSI1(coef_n,e,s,d);
fz=PSI1(coef_z,e,s,d);

for i=1:length(s)
    fval(:,:,i)=[fs(i,:),zeros(1,Nm_o)
                 fn(i,:),zeros(1,Nm_o)
                 zeros(1,Nm_i),fz(i,:)];
end