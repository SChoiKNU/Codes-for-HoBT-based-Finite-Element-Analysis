function [cnt,theta]=gcenter(cnr,cnr_con)

[~,a,L]=pcoord(cnr,cnr_con);

%%%%% center %%%%%
X=cnr(cnr_con(:,1),1);
Y=cnr(cnr_con(:,1),2);
Xg=sum(X.*L+0.5*cos(a).*L.*L)/sum(L);
Yg=sum(Y.*L+0.5*sin(a).*L.*L)/sum(L);
cnt=[Xg,Yg];

%%%%% principal axis for rotation modes %%%%%
xc=cnr(cnr_con(:,1),1)-cnt(1);
yc=cnr(cnr_con(:,1),2)-cnt(2);

aa=sum(yc.^2.*L + yc.*sin(a).*L.^2 + 1/3*sin(a).^2.*L.^3);
bb=sum(xc.^2.*L + xc.*cos(a).*L.^2 + 1/3*cos(a).^2.*L.^3);
cc=sum(xc.*yc.*L + 1/2*xc.*sin(a).*L.^2 + 1/2*yc.*cos(a).*L.^2 + 1/3*sin(a).*cos(a).*L.^3);

theta=0.5*atan(2*cc/(bb-aa));