%% HoBT Analysis for the numerical problem shown in Figure 7.13 (Table 7.1)

% This this code only considers vertical bending modes, especially Uy, Tx, C1, W1, C2, W2, C3, W3, N1_1, N1_2 (i.e., N1=3, N2=1)
% This code calculates natural frequencies (and mode shapes) for the problem in Figures 7.13

%%
clearvars;
clc;

%% Given Parameter Values
%  n: number of discretization
%  n_ele: number of elements that consist the box beam in Figure 7.13
%  n_nod: number of nodes involved in the box beam in Figure 7.13
% nod_dis: number of nodal kinematic variables per node (i.e.,  {Uy, Tx, C1, W1, C1', C2, W2, C2', C3, W3, C3', N1_1, N1_2, N1_1', N1_2'})
% glo_dis: number of total nodal kinematic variables
% mat_glo_K: global stiffness matrix K
% mat_glo_M: global mass matrix M

load K_matrix_b100_h50.mat
load M_matrix_b100_h50.mat

n=80;
n_ele=80;
n_nod=81;

nod_dis=15;

glo_dis=nod_dis*n_nod;

mat_glo_K=zeros(glo_dis,glo_dis);
mat_glo_M=zeros(glo_dis,glo_dis);

% yy_i: resulting vlaue of the ith kinematic variable along the axial direction
 % yy_1: Uy,    yy_2: Tx, 
 % yy_3: C1,    yy_4: W1,    yy_5: C1',
 % yy_6: C2,    yy_7: W2,    yy_8: C2',
 % yy_9: C3,    yy_10: W3,   yy_11: C3',
 % yy_12: N1_1, yy_13: N1_2, yy_14: N1_1', yy_15: N1_2'

 yy_1=zeros(n_nod,1);      yy_2=zeros(n_nod,1);
 yy_3=zeros(n_nod,1);      yy_4=zeros(n_nod,1);    yy_5=zeros(n_nod,1);
 yy_6=zeros(n_nod,1);      yy_7=zeros(n_nod,1);    yy_8=zeros(n_nod,1);
 yy_9=zeros(n_nod,1);     yy_10=zeros(n_nod,1);   yy_11=zeros(n_nod,1);
yy_12=zeros(n_nod,1);     yy_13=zeros(n_nod,1);   yy_14=zeros(n_nod,1);   yy_15=zeros(n_nod,1);


%% Calculate Global Stiffness Matrix and Mass Matrix

for ii=1:1:(n_nod-1)
    mat_glo_K((nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis),(nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis))=mat_glo_K((nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis),(nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis))+local_K_VB;
    mat_glo_M((nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis),(nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis))=mat_glo_M((nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis),(nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis))+local_M_VB;
end

%% Solve the eigen value problem in Figure 7.13 (see Eq. (3.37))
% freq_val: the resulting values of the natural frequencies for the problem in Figure 7.13

disp_BC=[1:glo_dis];

[V,D]=eig(mat_glo_K(disp_BC,disp_BC),mat_glo_M(disp_BC,disp_BC));

freq_val=sqrt(diag(D))/(2*pi);

    


