function ord=order(coef)

Ne=size(coef,3);
Nm=size(coef,2);

ord=zeros(Ne,Nm);
for i=1:Ne
    for j=1:Nm
        f=coef(:,j,i);
        ord_ij=find(f~=0,1,'last')-1;
        if isempty(ord_ij)
            ord_ij=0;
        end
        ord(i,j)=ord_ij;
    end
end