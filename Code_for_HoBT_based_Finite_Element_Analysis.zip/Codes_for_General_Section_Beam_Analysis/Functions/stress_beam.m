function LS=stress_beam(coef_s,coef_n,coef_z,esn,D,prpt)

%%% problem definition
L=prpt(2); % length of the beam
E=prpt(3);
nu=prpt(4);
Nel=prpt(5); % number of element for each beam

%%% problem property
Nmode=size(coef_s,2)+size(coef_z,2);
Ndof=Nmode*2; % number of DOF / to use Hermite interpolation functions
Le=L/Nel; % length of each element

%%% matrial property
E1=E/(1-nu^2);
C=E1*[1 nu 0;nu 1 0;0 0 (1-nu)/2];

%%% displacement (D -> d)
d=zeros(Ndof*2,Nel);
for i=1:Nel
    rng=(i-1)*Ndof+1:(i-1)*Ndof+Ndof*2;
    d(:,i)=D(rng);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% Hermite interpolation terms %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N1=@(L,k) 1/4*(1-k)^2*(2+k);
N2=@(L,k) L/8*(1-k)^2*(1+k);
N3=@(L,k) 1/4*(1+k)^2*(2-k);
N4=@(L,k) L/8*(1+k)^2*(k-1);
dN1=@(L,k) ((k-1)^2/4+((2*k-2)*(k+2))/4)*2/L;
dN2=@(L,k) ((L*(k-1)^2)/8+(L*(2*k-2)*(k+1))/8)*2/L;
dN3=@(L,k) (-(k+1)^2/4-((2*k+2)*(k-2))/4)*2/L;
dN4=@(L,k) ((L*(k+1)^2)/8+(L*(2*k+2)*(k-1))/8)*2/L;
ddN1=@(L,k) (3*k)/2*(2/L)^2;
ddN2=@(L,k) ((L*(k+1))/4+(L*(2*k-2))/4)*(2/L)^2;
ddN3=@(L,k) (-(3*k)/2)*(2/L)^2;
ddN4=@(L,k) ((L*(k-1))/4+(L*(2*k+2))/4)*(2/L)^2;

N=@(L,k) [eye(Nmode)*N1(L,k),eye(Nmode)*N2(L,k),eye(Nmode)*N3(L,k),eye(Nmode)*N4(L,k)];
dN=@(L,k) [eye(Nmode)*dN1(L,k),eye(Nmode)*dN2(L,k),eye(Nmode)*dN3(L,k),eye(Nmode)*dN4(L,k)];
ddN=@(L,k) [eye(Nmode)*ddN1(L,k),eye(Nmode)*ddN2(L,k),eye(Nmode)*ddN3(L,k),eye(Nmode)*ddN4(L,k)];

%%% calculation matrix
L1=[1 0 0;0 0 1];
L2=[0 1 0;0 0 0];
L3=[0 0 0;0 1 0];
L4=[1 0;0 0;0 1];
L5=[0 0;0 1;1 0];

La=L4*L1;
Lb=L5*L1;
Lc=L4*L2;
Ld=L4*L3+L5*L2;
Lf=L5*L3;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% beam stress calculation %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

e=esn(1); % edge
s=esn(2); % s-coordinate to scope
n=esn(3); % n-coordinate to scope

%%% cross-section shape functions
f=PSI(coef_s,coef_n,coef_z,e,s,0);
df=PSI(coef_s,coef_n,coef_z,e,s,1);
ddf=PSI(coef_s,coef_n,coef_z,e,s,2);

%%% HoBT stress calculation
eps1=La*df*N(Le,-1)+Lb*f*dN(Le,-1)-n*Lc*ddf*N(Le,-1)-n*Ld*df*dN(Le,-1)-n*Lf*f*ddN(Le,-1);
eps2=La*df*N(Le,+1)+Lb*f*dN(Le,+1)-n*Lc*ddf*N(Le,+1)-n*Ld*df*dN(Le,+1)-n*Lf*f*ddN(Le,+1);

stress1=C*eps1*d;
stress2=C*eps2*d;

%%% line stress
LS=zeros(Nel+1,3);
LS(1:Nel,:)=stress1';
LS(2:Nel+1,:)=LS(2:Nel+1,:)+stress2';
LS(2:Nel,:)=LS(2:Nel,:)/2;