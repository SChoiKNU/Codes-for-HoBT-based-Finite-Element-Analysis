%% Sectional Shape Function of the 2nd-Order Type 1 Constraint Distortion Mode N2_1

% Note that this code only considers torsional modes.

%  b:  width of the box beam section
%  h: height of the box beam section
% ss: s coordinate of the local coordinate system (z, n, s)

% pnN2_1: n-directional shape function of N2_1
% pnN2_1_j: pnN2_1 for edge j (j=1, 2, 3, 4)

%%
clearvars;
clc;
        
        syms b h ss

%% Load Sectional Shape Functions for modes N1_1 and N1_2

        load Sec_Shape_Func_N1_1.mat
        load Sec_Shape_Func_N1_2.mat

%% Calculation of unknown coefficients (C1, C2, C3, D1, D2, D3, D4) included in pnN2_1 (see Eq. (5.107))

% C1 = mat_N1_1(1)
% C2 = mat_N1_1(2)
% C3 = mat_N1_1(3)
% D1 = mat_N1_1(4)
% D2 = mat_N1_1(5)
% D3 = mat_N1_1(6)
% D4 = mat_N1_1(7)

% DIF_N1_1: derivative of pnN1_1
        
        DIF_N1_1_1=diff(pnN1_1_1,ss);        DIF_N1_1_2=diff(pnN1_1_2,ss);
        DIF_N1_1_3=diff(pnN1_1_3,ss);        DIF_N1_1_4=diff(pnN1_1_4,ss);

% DIF_N1_2: derivative of pnN1_2
        
        DIF_N1_2_1=diff(pnN1_2_1,ss);        DIF_N1_2_2=diff(pnN1_2_2,ss);
        DIF_N1_2_3=diff(pnN1_2_3,ss);        DIF_N1_2_4=diff(pnN1_2_4,ss);
        

% Considering the conditions defined in Eq. (5.108)
        
        mat_A = [  (h/2)   (h/2)^3      (h/2)^5        0              0                0               0;
                      0          0            0    (-b/2)      (-b/2)^3         (-b/2)^5        (-b/2)^7;
                      1  3*(h/2)^2    5*(h/2)^4        0              0                0               0;
                      0          0            0        1     3*(-b/2)^2       5*(-b/2)^4      7*(-b/2)^6;
                      0    6*(h/2)   20*(h/2)^3        0     (-6)*(-b/2)  (-20)*(-b/2)^3  (-42)*(-b/2)^5;
                      int((DIF_N1_1_1)*(1),ss,-h/2,h/2)   int((DIF_N1_1_1)*(3*(ss)^2),ss,-h/2,h/2)   int((DIF_N1_1_1)*(5*(ss)^4),ss,-h/2,h/2)   int((DIF_N1_1_2)*(1),ss,-b/2,b/2)   int((DIF_N1_1_2)*(3*(ss)^2),ss,-b/2,b/2)   int((DIF_N1_1_2)*(5*(ss)^4),ss,-b/2,b/2)   int((DIF_N1_1_2)*(7*(ss)^6),ss,-b/2,b/2);
                      int((DIF_N1_2_1)*(1),ss,-h/2,h/2)   int((DIF_N1_2_1)*(3*(ss)^2),ss,-h/2,h/2)   int((DIF_N1_2_1)*(5*(ss)^4),ss,-h/2,h/2)   int((DIF_N1_2_2)*(1),ss,-b/2,b/2)   int((DIF_N1_2_2)*(3*(ss)^2),ss,-b/2,b/2)   int((DIF_N1_2_2)*(5*(ss)^4),ss,-b/2,b/2)   int((DIF_N1_2_2)*(7*(ss)^6),ss,-b/2,b/2)];

                  
        mat_B = [    -(h/2)^7;
                            0;
                   -7*(h/2)^6;
                            0;
                  -42*(h/2)^5;
                  -int((DIF_N1_1_1)*(7*(ss)^6),ss,-h/2,h/2);
                  -int((DIF_N1_2_1)*(7*(ss)^6),ss,-h/2,h/2)];

% Determining the unknown coefficients
              
        mat_N2_1=(mat_A)\(mat_B);

        
%% Closed-Form Expression of pnN2_1 (see Eq. (5.107))

% C2_star: scaling constant of mode N2_1
        
        Coeff_N2_1=formula(mat_N2_1);

        C2_star=(1/100)/(Coeff_N2_1(1)*(h/4)+Coeff_N2_1(2)*(h/4)^3+Coeff_N2_1(3)*(h/4)^5+(h/4)^7);

        pnN2_1_1(b, h, ss) = (C2_star)*(Coeff_N2_1(1)*(ss)+Coeff_N2_1(2)*(ss)^3+Coeff_N2_1(3)*(ss)^5+(ss)^7);        pnN2_1_2(b, h, ss) = (C2_star)*(Coeff_N2_1(4)*(ss)+Coeff_N2_1(5)*(ss)^3+Coeff_N2_1(6)*(ss)^5+Coeff_N2_1(7)*(ss)^7);
        pnN2_1_3(b, h, ss) = (C2_star)*(Coeff_N2_1(1)*(ss)+Coeff_N2_1(2)*(ss)^3+Coeff_N2_1(3)*(ss)^5+(ss)^7);        pnN2_1_4(b, h, ss) = (C2_star)*(Coeff_N2_1(4)*(ss)+Coeff_N2_1(5)*(ss)^3+Coeff_N2_1(6)*(ss)^5+Coeff_N2_1(7)*(ss)^7);
        

%% Save the resulting pnN2_1
                
        save Sec_Shape_Func_N2_1.mat  pnN2_1_1  pnN2_1_2  pnN2_1_3  pnN2_1_4


        
        
        