%% Stiffness Matrix Calculation Code

% This code considers the numerical problem shown in Figure 7.13
% Thus, this code only considers vertical bending modes, especially Uy, Tx, C1, W1, C2, W2, C3, W3, N1_1, N1_2 (i.e., N1=3, N2=1)

%  ss: s coordinate of the local coordinate system (z, n, s)
%  nn: n coordinate of the local coordinate system (z, n, s)
% csy: z-directional natural coordinate (-1 <= csy <= 1)

% Uy: Rigid-body translation along the y direction (vertical displacement)
% Tx: Rigid-body rotation along the x direction (bending rotation)
% C1: 1st-order unconstrained distortion mode
% W1: 1st-order warping mode
% N1_1: 1st-order Type 1 constrained distortion mode
% N1_2: 1st-order Type 2 constrained distortion mode

% psC1: s-directional shape function of C1
% psC1_j: psC1 for edge j (j=1, 2, 3, 4)
% pnC1: n-directional shape function of C1
% pnC1_j: pnC1 for edge j (j=1, 2, 3, 4)
% -> The same notations are also used for other modes (e.g., Uy, Tx, C1, W1...).

%%
clearvars;
clc;

        syms ss nn csy

%% Given Parameter Values

%  b_val: value of the box beam section width
%  h_val: value of the box beam section height
%  t_val: value of the box beam section thickness
%  E: Young's modulus
%  v: Poisson's ratio
%  G: Shear modulus
%  L: Length of the box beam member
%  n: number of discretization
%  ele_L: Length of the box beam element
      
b_val=0.100;     
h_val=0.050;     
t_val=0.002;

E=200*10^(9);
v=0.3;
E_1=E/(1-v^2);
G=E/(2*(1+v));

L=1;
n=160;

ele_L=L/n;

%% Define Sectional Shape Functions for the box beam with (b_val, h_val)

load Sec_Shape_Func_b100_h50.mat

    % Edge 1 Section-Shape Functions
        
        pnUy_1= 0;
        psUy_1= 1;
        pzUy_1= 0;
        
        pnTx_1= 0;
        psTx_1= 0;
        pzTx_1= ss;
        
        % membrane 1st set
        
        pnC1_1=given_pnC1_1;
        psC1_1=given_psC1_1;
        pzC1_1=0;

        pnW1_1=0;
        psW1_1=0;
        pzW1_1=given_pzW1_1;
        
        % membrane 2nd set
        
        pnC2_1=given_pnC2_1;
        psC2_1=given_psC2_1;
        pzC2_1=0;

        pnW2_1=0;
        psW2_1=0;
        pzW2_1=given_pzW2_1;
        
        % membrane 3rd set
        
        pnC3_1=given_pnC3_1;
        psC3_1=given_psC3_1;
        pzC3_1=0;

        pnW3_1=0;
        psW3_1=0;
        pzW3_1=given_pzW3_1;
        
        % edge-bending 1st set
        
        pnN1_1_1=given_pnN1_1_1;
        psN1_1_1=0;
        pzN1_1_1=0;
        
        pnN1_2_1=given_pnN1_2_1;
        psN1_2_1=0;
        pzN1_2_1=0;
        
        
    % Edge 2 Section-Shape Functions
        
        pnUy_2= 1;
        psUy_2= 0;
        pzUy_2= 0;
        
        pnTx_2= 0;
        psTx_2= 0;
        pzTx_2= (h_val/2+nn);
        
        % membrane 1st set
        
        pnC1_2=given_pnC1_2;
        psC1_2=given_psC1_2;
        pzC1_2=0;

        pnW1_2=0;
        psW1_2=0;
        pzW1_2=given_pzW1_2;
        
        % membrane 2nd set
        
        pnC2_2=given_pnC2_2;
        psC2_2=given_psC2_2;
        pzC2_2=0;

        pnW2_2=0;
        psW2_2=0;
        pzW2_2=given_pzW2_2;
        
        % membrane 3rd set
        
        pnC3_2=given_pnC3_2;
        psC3_2=given_psC3_2;
        pzC3_2=0;

        pnW3_2=0;
        psW3_2=0;
        pzW3_2=given_pzW3_2;
        
        % edge-bending 1st set
        
        pnN1_1_2=given_pnN1_1_2;
        psN1_1_2=0;
        pzN1_1_2=0;
        
        pnN1_2_2=given_pnN1_2_2;
        psN1_2_2=0;
        pzN1_2_2=0;
        
        
    % Edge 3 Section-Shape Functions
        
        pnUy_3= 0;
        psUy_3=-1;
        pzUy_3= 0;
        
        pnTx_3= 0;
        psTx_3= 0;
        pzTx_3=-ss;
        
        % membrane 1st set
        
        pnC1_3=given_pnC1_3;
        psC1_3=given_psC1_3;
        pzC1_3=0;

        pnW1_3=0;
        psW1_3=0;
        pzW1_3=given_pzW1_3;
        
        % membrane 2nd set
        
        pnC2_3=given_pnC2_3;
        psC2_3=given_psC2_3;
        pzC2_3=0;

        pnW2_3=0;
        psW2_3=0;
        pzW2_3=given_pzW2_3;
        
        % membrane 3rd set
        
        pnC3_3=given_pnC3_3;
        psC3_3=given_psC3_3;
        pzC3_3=0;

        pnW3_3=0;
        psW3_3=0;
        pzW3_3=given_pzW3_3;
        
        % edge-bending 1st set
        
        pnN1_1_3=given_pnN1_1_3;
        psN1_1_3=0;
        pzN1_1_3=0;
        
        pnN1_2_3=given_pnN1_2_3;
        psN1_2_3=0;
        pzN1_2_3=0;
        
        
    % Edge 4 Section-Shape Functions
        
        pnUy_4=-1;
        psUy_4= 0;
        pzUy_4= 0;
        
        pnTx_4= 0;
        psTx_4= 0;
        pzTx_4=-(h_val/2+nn);
        
        % membrane 1st set
        
        pnC1_4=given_pnC1_4;
        psC1_4=given_psC1_4;
        pzC1_4=0;

        pnW1_4=0;
        psW1_4=0;
        pzW1_4=given_pzW1_4;
        
        % membrane 2nd set
        
        pnC2_4=given_pnC2_4;
        psC2_4=given_psC2_4;
        pzC2_4=0;

        pnW2_4=0;
        psW2_4=0;
        pzW2_4=given_pzW2_4;
        
        % membrane 3rd set
        
        pnC3_4=given_pnC3_4;
        psC3_4=given_psC3_4;
        pzC3_4=0;

        pnW3_4=0;
        psW3_4=0;
        pzW3_4=given_pzW3_4;
        
        % edge-bending 1st set
        
        pnN1_1_4=given_pnN1_1_4;
        psN1_1_4=0;
        pzN1_1_4=0;
        
        pnN1_2_4=given_pnN1_2_4;
        psN1_2_4=0;
        pzN1_2_4=0;
        

%% Define Interpolation Functions
% Linear interpolation functions:  (1-csy)/2, (1+csy)/2
% Hermite interpolation functions: (1/4)*(1-csy)^2*(2+csy),(ele_L/8)*(1-csy)^2*(1+csy), (1/4)*(1+csy)^2*(2-csy), (ele_L/8)*(1+csy)^2*(csy-1)
% Kinematic variables per node: {Uy, Tx, C1, W1, C1', C2, W2, C2', C3, W3, C3', N1_1, N1_2, N1_1', N1_2'}
% C1', C2', C3', N1_1', N1_2': z-directional derivatives of C1, C2, C3, N1_1, and N1_2
        
        mat_H=[(1-csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0 0;
               0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0;
               0 0 (1/4)*(1-csy)^2*(2+csy) 0 (ele_L/8)*(1-csy)^2*(1+csy) 0 0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1+csy)^2*(2-csy) 0 (ele_L/8)*(1+csy)^2*(csy-1) 0 0 0 0 0 0 0 0 0 0;
               0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0 0 0 0 0 0 0;
               0 0 0 0 0 (1/4)*(1-csy)^2*(2+csy) 0 (ele_L/8)*(1-csy)^2*(1+csy) 0 0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1+csy)^2*(2-csy) 0 (ele_L/8)*(1+csy)^2*(csy-1) 0 0 0 0 0 0 0;
               0 0 0 0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0 0 0 0;
               0 0 0 0 0 0 0 0 (1/4)*(1-csy)^2*(2+csy) 0 (ele_L/8)*(1-csy)^2*(1+csy) 0 0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1+csy)^2*(2-csy) 0 (ele_L/8)*(1+csy)^2*(csy-1) 0 0 0 0;
               0 0 0 0 0 0 0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0;
               0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1-csy)^2*(2+csy) 0 (ele_L/8)*(1-csy)^2*(1+csy) 0 0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1+csy)^2*(2-csy) 0 (ele_L/8)*(1+csy)^2*(csy-1) 0;
               0 0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1-csy)^2*(2+csy) 0 (ele_L/8)*(1-csy)^2*(1+csy) 0 0 0 0 0 0 0 0 0 0 0 0 (1/4)*(1+csy)^2*(2-csy) 0 (ele_L/8)*(1+csy)^2*(csy-1)];
           

%% Define Displacement Field (see Eqs. (7.2), (7.75), (7.78), and (7.79))        
% dis_n_j: n-directional displacement at edge j (j=1, 2, 3, 4)
% dis_s_j: s-directional displacement at edge j (j=1, 2, 3, 4)
% dis_z_j: z-directional displacement at edge j (j=1, 2, 3, 4)

        dis_n_1=[     0 pnTx_1 pnC1_1 pnW1_1 pnC2_1 pnW2_1 pnC3_1 pnW3_1 pnN1_1_1 pnN1_2_1]*mat_H;
        dis_s_1=[psUy_1 psTx_1 psC1_1 psW1_1 psC2_1 psW2_1 psC3_1 psW3_1 psN1_1_1 psN1_2_1]*mat_H -nn*diff(dis_n_1,ss);
        dis_z_1=[pzUy_1 pzTx_1 pzC1_1 pzW1_1 pzC2_1 pzW2_1 pzC3_1 pzW3_1 pzN1_1_1 pzN1_2_1]*mat_H -nn*diff(dis_n_1,csy)*(2/ele_L);

        dis_n_2=[     0 pnTx_2 pnC1_2 pnW1_2 pnC2_2 pnW2_2 pnC3_2 pnW3_2 pnN1_1_2 pnN1_2_2]*mat_H;
        dis_s_2=[psUy_2 psTx_2 psC1_2 psW1_2 psC2_2 psW2_2 psC3_2 psW3_2 psN1_1_2 psN1_2_2]*mat_H -nn*diff(dis_n_2,ss);
        dis_z_2=[pzUy_2 pzTx_2 pzC1_2 pzW1_2 pzC2_2 pzW2_2 pzC3_2 pzW3_2 pzN1_1_2 pzN1_2_2]*mat_H -nn*diff(dis_n_2,csy)*(2/ele_L);
        
        dis_n_3=[     0 pnTx_3 pnC1_3 pnW1_3 pnC2_3 pnW2_3 pnC3_3 pnW3_3 pnN1_1_3 pnN1_2_3]*mat_H;
        dis_s_3=[psUy_3 psTx_3 psC1_3 psW1_3 psC2_3 psW2_3 psC3_3 psW3_3 psN1_1_3 psN1_2_3]*mat_H -nn*diff(dis_n_3,ss);
        dis_z_3=[pzUy_3 pzTx_3 pzC1_3 pzW1_3 pzC2_3 pzW2_3 pzC3_3 pzW3_3 pzN1_1_3 pzN1_2_3]*mat_H -nn*diff(dis_n_3,csy)*(2/ele_L);
        
        dis_n_4=[     0 pnTx_4 pnC1_4 pnW1_4 pnC2_4 pnW2_4 pnC3_4 pnW3_4 pnN1_1_4 pnN1_2_4]*mat_H;
        dis_s_4=[psUy_4 psTx_4 psC1_4 psW1_4 psC2_4 psW2_4 psC3_4 psW3_4 psN1_1_4 psN1_2_4]*mat_H -nn*diff(dis_n_4,ss);
        dis_z_4=[pzUy_4 pzTx_4 pzC1_4 pzW1_4 pzC2_4 pzW2_4 pzC3_4 pzW3_4 pzN1_1_4 pzN1_2_4]*mat_H -nn*diff(dis_n_4,csy)*(2/ele_L);


%% Define Strain Field (see Eqs. (7.4) and (7.80))        
% str_zz_j: z-directional normal strain at edge j (j=1, 2, 3, 4)
% str_ss_j: s-directional normal strain at edge j (j=1, 2, 3, 4)
% str_sz_j: shear strain at edge j (j=1, 2, 3, 4)

        str_zz_1=diff(dis_z_1,csy)*(2/ele_L);
        str_ss_1=diff(dis_s_1,ss);
        str_sz_1=diff(dis_z_1,ss)+diff(dis_s_1,csy)*(2/ele_L);

        str_zz_2=diff(dis_z_2,csy)*(2/ele_L);
        str_ss_2=diff(dis_s_2,ss);
        str_sz_2=diff(dis_z_2,ss)+diff(dis_s_2,csy)*(2/ele_L);

        str_zz_3=diff(dis_z_3,csy)*(2/ele_L);
        str_ss_3=diff(dis_s_3,ss);
        str_sz_3=diff(dis_z_3,ss)+diff(dis_s_3,csy)*(2/ele_L);

        str_zz_4=diff(dis_z_4,csy)*(2/ele_L);
        str_ss_4=diff(dis_s_4,ss);
        str_sz_4=diff(dis_z_4,ss)+diff(dis_s_4,csy)*(2/ele_L);


%% Define Constitutive Relations (see Eqs. (7.5) and (7.81))

        mat_C=[E_1      E_1*v    0;
               E_1*v    E_1      0;
               0        0        G];


%% Calculate Stiffness Matrix (see Eqs. (3.24), (7.7), and (7.82))       
% mat_K_j: local stiffness matrix K calculated at edge j (j=1, 2, 3, 4)

        mat_B_1=[str_zz_1;
                 str_ss_1;
                 str_sz_1];
                            
        mat_B_2=[str_zz_2;
                 str_ss_2;
                 str_sz_2];
               
        mat_B_3=[str_zz_3;
                 str_ss_3;
                 str_sz_3];
        
        mat_B_4=[str_zz_4;
                 str_ss_4;
                 str_sz_4];

               
        mat_K_1=(mat_B_1)'*mat_C*mat_B_1;

        mat_K_2=(mat_B_2)'*mat_C*mat_B_2;
  
        mat_K_3=(mat_B_3)'*mat_C*mat_B_3;
        
        mat_K_4=(mat_B_4)'*mat_C*mat_B_4;

        
        mat_K_13=mat_K_1+mat_K_3;

        mat_K_24=mat_K_2+mat_K_4;

          
% Volume integration to obtain the element stiffness matrix (see Eq. (3.27)) 
          
        local_K_13=zeros(30,30);
        local_K_24=zeros(30,30);
        
        
        for ii=1:30
            for jj=1:30
                local_K_13(ii,jj)=int(int(int(mat_K_13(ii,jj),ss,-(h_val/2),(h_val/2)),nn,-(t_val/2),t_val/2),csy,-1,1)*(ele_L/2);
            end
        end
        
        for ii=1:30
            for jj=1:30
                local_K_24(ii,jj)=int(int(int(mat_K_24(ii,jj),ss,-(b_val/2),(b_val/2)),nn,-(t_val/2),t_val/2),csy,-1,1)*(ele_L/2);
            end
        end        

        
% local_K: The resulting element stiffness matrix

        local_K=local_K_13+local_K_24;
        
        save K_matrix_b100_h50.mat local_K
        


        