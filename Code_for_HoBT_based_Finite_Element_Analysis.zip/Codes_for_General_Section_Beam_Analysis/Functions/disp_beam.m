function LD=disp_beam(coef_s,coef_n,coef_z,es,D)

%%% problem property
Nmode=size(coef_s,2)+size(coef_z,2);
Ndof=Nmode*2; % number of DOF / to use Hermite interpolation functions
Nn=length(D)/Ndof;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% displacement calculation %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
e=es(1); % edge
s=es(2); % s-coordinate

%%% dof
d=zeros(Nn,Nmode);
for i=1:Nn
    rng=(i-1)*Ndof+1:(i-1)*Ndof+Nmode;
    d(i,:)=D(rng);
end 

%%% displacement by HoBT
LD=d*PSI(coef_s,coef_n,coef_z,e,s,0)';