%% Sectional Shape Function of the 2nd-Order Unconstrained Distortion Mode C2 (Chi_2)

% Note that this code only considers torsional modes.

%  b:  width of the box beam section
%  h: height of the box beam section
% ss: s coordinate of the local coordinate system (z, n, s)

% Tz: Rigid-body torsional rotation
% C0: Fundamental unconstrained distortion mode (Chi_0)
% W0: Fundamental warping mode
% C1: 1st-order unconstrained distortion mode (Chi_1)
% W1: 1st-order warping mode

% psC2: s-directional shape function of C2
% psC2_j: psC2 for edge j (j=1, 2, 3, 4)
% pnC2: n-directional shape function of C2
% pnC2_j: pnC2 for edge j (j=1, 2, 3, 4)
% -> The same notations are also used for other modes (i.e., Tz, C0, W0, C1, W1).

%%
clearvars;
clc;
        
        syms b h ss

%% Load Sectional Shape Functions for modes Tz, C0, W0, C1, W1

        load Sec_Shape_Func_Tz.mat
        load Sec_Shape_Func_C0.mat
        load Sec_Shape_Func_W0.mat
        load Sec_Shape_Func_C1.mat
        load Sec_Shape_Func_W1.mat

%% Calculation of unknown coefficients (D1, C1, C2, C3, C4) included in psC2 (see Eq. (4.85))

% D1 = mat_C2s(1)
% C1 = mat_C2s(2)
% C2 = mat_C2s(3)
% C3 = mat_C2s(2)
% C4 = mat_C2s(3) (see Eq. (4.87))

% PSI_W0: Indefinite integral of pzW0
        
        PSI_W0_1(b, h, ss)=int(pzW0_1,ss);        PSI_W0_2(b, h, ss)=int(pzW0_2,ss);
        PSI_W0_3(b, h, ss)=int(pzW0_3,ss);        PSI_W0_4(b, h, ss)=int(pzW0_4,ss);
        
% PSI_W1: Indefinite integral of pzW1
        
        PSI_W1_1(b, h, ss)=int(pzW1_1,ss);        PSI_W1_2(b, h, ss)=int(pzW1_2,ss);
        PSI_W1_3(b, h, ss)=int(pzW1_3,ss);        PSI_W1_4(b, h, ss)=int(pzW1_4,ss);
                
% Considering the orthogonality conditions defined in Eq. (4.86)

        mat_A = [    (int((psTz_1)*(-PSI_W1_1),ss,-h/2,h/2)+int((psTz_2)*(-PSI_W1_2),ss,-b/2,b/2))     int(psTz_1,ss,-h/2,h/2)     int(psTz_2,ss,-b/2,b/2);
                     (int((psC0_1)*(-PSI_W1_1),ss,-h/2,h/2)+int((psC0_2)*(-PSI_W1_2),ss,-b/2,b/2))     int(psC0_1,ss,-h/2,h/2)     int(psC0_2,ss,-b/2,b/2);
                     (int((psC1_1)*(-PSI_W1_1),ss,-h/2,h/2)+int((psC1_2)*(-PSI_W1_2),ss,-b/2,b/2))     int(psC1_1,ss,-h/2,h/2)     int(psC1_2,ss,-b/2,b/2)];
             
        mat_B = [    -int((psTz_1)*(-PSI_W0_1),ss,-h/2,h/2)-int((psTz_2)*(-PSI_W0_2),ss,-b/2,b/2);
                     -int((psC0_1)*(-PSI_W0_1),ss,-h/2,h/2)-int((psC0_2)*(-PSI_W0_2),ss,-b/2,b/2);
                     -int((psC1_1)*(-PSI_W0_1),ss,-h/2,h/2)-int((psC1_2)*(-PSI_W0_2),ss,-b/2,b/2)];

% Determining the unknown coefficients

        mat_C2s=(mat_A)\(mat_B);

%% Closed-Form Expression of psC2 (see Eq. (4.85))

% A2_star: scaling constant of mode C2

        Coeff_C2s=formula(mat_C2s);
        
        A2_star=(1/100)/(-PSI_W0_1(b, h, h/2)+Coeff_C2s(1)*(-PSI_W1_1(b, h, h/2))+Coeff_C2s(2));
        
        psC2_1(b, h, ss)= A2_star*(-PSI_W0_1+Coeff_C2s(1)*(-PSI_W1_1)+Coeff_C2s(2));        psC2_2(b, h, ss)= A2_star*(-PSI_W0_2+Coeff_C2s(1)*(-PSI_W1_2)+Coeff_C2s(3));
        psC2_3(b, h, ss)= A2_star*(-PSI_W0_1+Coeff_C2s(1)*(-PSI_W1_1)+Coeff_C2s(2));        psC2_4(b, h, ss)= A2_star*(-PSI_W0_2+Coeff_C2s(1)*(-PSI_W1_2)+Coeff_C2s(3));

%% Calculation of unknown coefficients (C1,1 , C2,1 , C3,1 , C4,1) included in pnC2 (see Eq. (5.33))

% C1,1 = mat_C2n(1)
% C2,1 = mat_C2n(2)
% C3,1 = mat_C2n(1)
% C4,1 = mat_C2n(2) (see Eqs. (5.37a) and (5.37b))

% Considering the displacement continuity conditions defined in Eq. (5.36c)
        
        mat_A= [ (h/2)       0;
                    0   (-b/2)];
        
        mat_B= [ -(1/6)*(h/2)^3-(1/A2_star)*psC2_2(b, h, -b/2);
                 (1/6)*(-b/2)^3+(1/A2_star)*psC2_1(b, h, h/2)];

% Determining the unknown coefficients
              
        mat_C2n=(mat_A)\(mat_B);

        
%% Closed-Form Expression of pnC1 (see Eq. (5.33))
        
        Coeff_C2n=formula(mat_C2n);
        
        pnC2_1(b, h, ss)= A2_star*( (1/6)*(ss)^3+Coeff_C2n(1)*(ss));        pnC2_2(b, h, ss)= A2_star*(-(1/6)*(ss)^3+Coeff_C2n(2)*(ss));
        pnC2_3(b, h, ss)= A2_star*( (1/6)*(ss)^3+Coeff_C2n(1)*(ss));        pnC2_4(b, h, ss)= A2_star*(-(1/6)*(ss)^3+Coeff_C2n(2)*(ss));
                
        save Sec_Shape_Func_C2.mat psC2_1  psC2_2  psC2_3  psC2_4  pnC2_1  pnC2_2  pnC2_3  pnC2_4
        

        
        