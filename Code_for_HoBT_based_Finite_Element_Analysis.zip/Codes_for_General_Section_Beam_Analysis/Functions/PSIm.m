function fval=PSIm(coef_s,coef_n,coef_z,e,s,d,m)
% row : snz
% col : value along s-points

Nm_i=size(coef_s,2); % # of in-plane modes

if m<=Nm_i
    fval_s=PSI1(coef_s(:,m,:),e,s,d)';
    fval_n=PSI1(coef_n(:,m,:),e,s,d)';
    fval_z=zeros(1,length(s));
else
    fval_s=zeros(1,length(s));
    fval_n=zeros(1,length(s));
    fval_z=PSI1(coef_z(:,m-Nm_i,:),e,s,d)';
end

fval=[fval_s
    fval_n
    fval_z];