%% HoBT Analysis for the numerical problem shown in Figure 5.5

% This code only considers torsional modes, especially Tz, C0, W0, C1, W1 (i.e., N1=1, N2=0)
% This code calculates the displacements uz and ux shown in Figures 5.5(b) and 5.5(c)
% uz: z-directional displacement
% ux: x-directional displacement

%%
clearvars;
clc;

%% Given Parameter Values
%  n: number of discretization
%  n_ele: number of elements that consist the box beam in Figure 5.5
%  n_nod: number of nodes involved in the box beam in Figure 5.5
% nod_dis: number of nodal kinematic variables per node (i.e.,  {Tz, C0, W0, Tz', C0', C1, W1, C1'})
% glo_dis: number of total nodal kinematic variables
% glo_frc: number of total nodal forces
% mat_glo_K: global stiffness matrix K
% mat_glo_dis: global nodal displacement vector
% mat_glo_frc: global nodal force vector

load K_matrix_b50_h75.mat

n=160;
n_ele=160;
n_nod=161;

nod_dis=8;

glo_dis=nod_dis*n_nod;
glo_frc=glo_dis;

mat_glo_K=zeros(glo_dis,glo_dis);
mat_glo_dis=zeros(glo_dis,1);
mat_glo_frc=zeros(glo_frc,1);

% apply the external twisting moment Mz=100 N*m at the end B (see Figure 5.5)
mat_glo_frc(nod_dis*(n_nod-1)+1,1)=100;

% yy_i: resulting vlaue of the ith kinematic variable along the axial direction
% yy_1: Tz, yy_2: C0, yy_3: W0, yy_4: Tz', yy_5: C0', yy_6: C1, yy_7: W1, yy_8: C1'

yy_1=zeros(n_nod,1);    yy_2=zeros(n_nod,1);    yy_3=zeros(n_nod,1);
yy_4=zeros(n_nod,1);    yy_5=zeros(n_nod,1);
yy_6=zeros(n_nod,1);    yy_7=zeros(n_nod,1);    yy_8=zeros(n_nod,1);

% nod_z: z-directional coordinate

nod_z=zeros(n_nod,1);

for ii=1:(n_nod)
nod_z(ii)=(ii-1)*(100/(n_nod-1));
end


%% Calculate Global Stiffness Matrix

for ii=1:1:(n_nod-1)
    mat_glo_K((nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis),(nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis))=mat_glo_K((nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis),(nod_dis*ii-(nod_dis-1)):(nod_dis*ii+nod_dis))+local_K;
end


%% Apply Boundary Conditions at Both Ends A and B

disp_BC=[4,5,8,(nod_dis+1):(nod_dis*(n_nod-1)+1),(nod_dis*(n_nod-1)+4),(nod_dis*(n_nod-1)+5),(nod_dis*(n_nod-1)+8)];

%% Solve the Finite Element Equations

mat_glo_dis(disp_BC,1)=mat_glo_K(disp_BC,disp_BC)\mat_glo_frc(disp_BC,1);


%% Obtained Field Variables Solution

for ii=1:1:n_nod
     yy_1(ii)=mat_glo_dis(nod_dis*(ii-1)+1);     yy_2(ii)=mat_glo_dis(nod_dis*(ii-1)+2);     yy_3(ii)=mat_glo_dis(nod_dis*(ii-1)+3);
     yy_4(ii)=mat_glo_dis(nod_dis*(ii-1)+4);     yy_5(ii)=mat_glo_dis(nod_dis*(ii-1)+5);     
     yy_6(ii)=mat_glo_dis(nod_dis*(ii-1)+6);     yy_7(ii)=mat_glo_dis(nod_dis*(ii-1)+7);     yy_8(ii)=mat_glo_dis(nod_dis*(ii-1)+8);
end

%% Plot the Displacement uz and ux along the measurement points (Edge 2, ss=b_val/8, see Figure 5.5)
%  b_val: value of the box beam section width
%  h_val: value of the box beam section height

b_val=0.050;
h_val=0.075;

% Define measurement points

ed_num=2;
ss=b_val/8*(1);

% Define sectional shape functions at the measurement points

       [pnTz,psTz,pzTz,pnC0,psC0,pzC0,pnW0,psW0,pzW0,pnC1,psC1,pzC1,pnW1,psW1,pzW1]=HoBT_Shapefunc(ss,ed_num);

        PSI = [pnTz pnC0 pnW0 pnC1 pnW1; 
               psTz psC0 psW0 psC1 psW1; 
               pzTz pzC0 pzW0 pzC1 pzW1];
           
n_displ_edge2=PSI(1,:)*[yy_1 yy_2 yy_3 yy_6 yy_7]';
s_displ_edge2=PSI(2,:)*[yy_1 yy_2 yy_3 yy_6 yy_7]';
z_displ_edge2=PSI(3,:)*[yy_1 yy_2 yy_3 yy_6 yy_7]';

% disp_Uz: z-directional displacement along the measurement points
% disp_Ux: x-directional displacement along the measurement points
disp_Uz= z_displ_edge2;
disp_Ux=-s_displ_edge2;

%% Plot the HoBT analysis results

figure(1);
plot(nod_z,disp_Uz,'b','LineWidth',1.1);
hold on;

figure(2);
plot(nod_z,disp_Ux,'b','LineWidth',1.1);
hold on;






