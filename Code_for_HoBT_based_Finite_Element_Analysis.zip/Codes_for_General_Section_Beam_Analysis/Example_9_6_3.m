%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% How to Use %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1. This code solves Example 9.6.3 and shows the analysis results.
% 2. M in line 32 indicates the highest mode set and you can set M to any
%    number up to 10.
% 3. You can check sectional mode shapes by setting 'plotopt' in line 134 
%    to 1.
% 4. All the function files used in this code can be found in the folder
%    'Function.'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('.\Functions')
clc,clear,close all

%%%%%%%%%%%%%%%% Beam dimension %%%%%%%%%%%%%%%%
% corner coordinate
cnr=[.04 .01;.04 0;.05 0;.05 .03;.04 .04;.01 .04;0 .03;0 .02;-.005 .02;-.01 .01;0 0;.03 0;.03 .01];
% corner connectivity
cnr_con=[1 2;2 3;3 4;4 5;5 6;6 7;7 8;8 9;9 10;10 11;11 12;12 13;13 1];
% thickness
t=2e-3; 
% beam length
L=0.4; 
% edge length
[~,~,Ledge]=pcoord(cnr,cnr_con);

%%%%%%%%%%%%%%%% Problem definition %%%%%%%%%%%%%%%%
% number of mode set
M=2;
% number of cross-section modes for each set
Nw=[13,13,13,13,13,13,13,13,13,13];
Nchi=[13,13,13,13,13,13,13,13,13,13];
Neta=[0,23,24,25,24,23,23,22,21,22];
% number of element
Nel=50; 
% material properties
E=200e9;
nu=0.3;
% property vector
prpt=[t,L,E,nu,Nel]; 

%%%%%%%%%%%%%%%% Mode determination %%%%%%%%%%%%%%%%
load('coef.mat')
% selection
col_w=1:sum(Nw(1:M-1)); % M-1 sets of warping modes are considered for the analysis efficiency
col_chi=1:sum(Nchi(1:M));
col_eta=(1:sum(Neta(1:M)))+sum(Nchi);
% coefficient matrix for the selected mode
coef_s=coef_s(:,[col_chi,col_eta],:);
coef_n=coef_n(:,[col_chi,col_eta],:);
coef_z=coef_z(:,col_w,:);

%%%%%%%%%%%%%%%% Problem definition %%%%%%%%%%%%%%%%
% number of cross-section modes considered
Ni=size(coef_s,2); % number of in-plane modes
No=size(coef_z,2); % number of out-of-plane modes
Nmode=Ni+No;
% number of nodal DOF (for the Hermite interpolation functions)
Ndof=Nmode*2; 

%%%%%%%%%%%%%%%% Stiffness matrix %%%%%%%%%%%%%%%%
K=stiffness3(cnr,cnr_con,coef_s,coef_n,coef_z,prpt);

%%%%%%%%%%%%%%%% Force vector %%%%%%%%%%%%%%%%
F=sparse(length(K),1);
forcedof=Nel*Ndof+1:Nel*Ndof+Nmode;
F(forcedof)=[-100,0,0]*PSI(coef_s,coef_n,coef_z,3,0,0);

%%%%%%%%%%%%%%% Static analysis %%%%%%%%%%%%%%%%
% boundary condition
fixdof=1:Nmode;
freedof=setdiff(1:length(K),fixdof);
% stiffness matrix inverse
D=zeros(length(K),1);
D(freedof)=K(freedof,freedof)\F(freedof);
d=zeros(Nel+1,Nmode);
for i=1:Nel+1
    rng=(i-1)*Ndof+1:(i-1)*Ndof+Nmode;
    d(i,:)=D(rng);
end

%%%%%%%%%%%%%%%%%%% Displacement & stress plot %%%%%%%%%%%%%%%%%%%
% edge number, edge length, n-coordinate
esn=[3,Ledge(3)*1/5,0];
% displacement
U=disp_beam(coef_s,coef_n,coef_z,esn,D);
U=U*[0 1 0;1 0 0;0 0 1]; % transform snz to xyz
% stress
S=stress_beam(coef_s,coef_n,coef_z,esn,D,prpt);
% plot
title_u={'\fontsize{12}u\fontsize{8}_{X} \fontsize{12}(m)'
    '\fontsize{12}u\fontsize{8}_{Y} \fontsize{12}(m)'
    '\fontsize{12}u\fontsize{8}_{Z} \fontsize{12}(m)'};

title_s={'\fontsize{12}\sigma\fontsize{8}_{YY} \fontsize{12}( N/m\fontsize{8}^2\fontsize{12} )'
    '\fontsize{12}\sigma\fontsize{8}_{ZZ} \fontsize{12}( N/m\fontsize{8}^2\fontsize{12} )'
    '\fontsize{12}\sigma\fontsize{8}_{ZY} \fontsize{12}( N/m\fontsize{8}^2\fontsize{12} )'};
z=linspace(0,L,Nel+1);
figure
for i=1:3
    subplot(2,3,i)
    plot(z,U(:,i),'k')
    title(title_u{i})
    subplot(2,3,i+3)
    plot(z,S(:,i),'k')
    title(title_s{i})
end

%%%%%%%%%%%%%%%%%%% Cross-section shape %%%%%%%%%%%%%%%%%%%
% cross-section
figure, hold on
modeshape(cnr,cnr_con,coef_s,coef_n,coef_z,1,0)
% torsional center & axes of deflections (axes in blue)
Laxis=0.01;
[cnt1,theta1]=scenter(cnr,cnr_con);
x1=[ cos(theta1),sin(theta1)]*Laxis+cnt1;
y1=[-sin(theta1),cos(theta1)]*Laxis+cnt1;
plot3([0,0],[cnt1(1),x1(1)],[cnt1(2),x1(2)],'color','blue','LineWidth',1);
plot3([0,0],[cnt1(1),y1(1)],[cnt1(2),y1(2)],'color','blue','LineWidth',1);
plot3(0,cnt1(1),cnt1(2),'*','color','blue','LineWidth',1)
% centroid & principal axes (axes in red)
[cnt2,theta2]=gcenter(cnr,cnr_con);
x1=[ cos(theta2),sin(theta2)]*Laxis+cnt2;
y1=[-sin(theta2),cos(theta2)]*Laxis+cnt2;
plot3([0,0],[cnt2(1),x1(1)],[cnt2(2),x1(2)],'color','red','LineWidth',1);
plot3([0,0],[cnt2(1),y1(1)],[cnt2(2),y1(2)],'color','red','LineWidth',1);
plot3(0,cnt2(1),cnt2(2),'o','color','red','LineWidth',1)

%%%%%%%%%%%%%%%%%%% Mode shapes %%%%%%%%%%%%%%%%%%%
% set plotopt=1 to plot the mode shapes
plotopt=0;
if plotopt==1
    scl=1; % scale factor
    for i=1:Nmode
        figure
        modeshape(cnr,cnr_con,coef_s,coef_n,coef_z,i,scl)
        % camera option
        cnt1=double(max(cnr)+min(cnr))/2;
        camtarget([0.008 cnt1])
        if i<=Ni
            camzoom(1.55)
        else
            camzoom(2.65)
        end
    end
end