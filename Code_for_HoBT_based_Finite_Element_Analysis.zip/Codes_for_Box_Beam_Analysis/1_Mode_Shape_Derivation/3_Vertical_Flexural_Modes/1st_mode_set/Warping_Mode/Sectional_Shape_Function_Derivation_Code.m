%% Sectional Shape Function of the 1st-Order Warping Mode W1

% Note that this code only considers vertical flexural modes.

%  b:  width of the box beam section
%  h: height of the box beam section
% ss: s coordinate of the local coordinate system (z, n, s)

% Uy: Rigid-body vertical displacement
% Tx: Rigid-body vertical rotation
% C1: 1st-Order Unconstrained Distortion Mode

% pzW1: z-directional shape function of W1
% pzW1_j: pzW1 for edge j (j=1, 2, 3, 4)

%%
clearvars;
clc;
        
        syms b h ss

%% Load Sectional Shape Functions for modes Uy, Tx, C1 (see Eqs. (7.3a), (7.3b))

        load Sec_Shape_Func_Uy.mat
        load Sec_Shape_Func_Tx.mat
        load Sec_Shape_Func_C1.mat
        
%% Calculation of unknown coefficients (D1, C2, C4) included in pzW1 (see Eq. (7.42))

% C1=C3=0 (see Eq. (7.46a))
% D1 = mat_W1z(1)
% C2 = mat_W1z(2)
% C4 =-mat_W1z(2)

% PSI_Uy: Indefinite integral of psUy
                
        PSI_Uy_1(b, h, ss)=int(psUy_1,ss);        PSI_Uy_2(b, h, ss)=int(psUy_2,ss);
        PSI_Uy_3(b, h, ss)=int(psUy_3,ss);        PSI_Uy_4(b, h, ss)=int(psUy_4,ss);

% PSI_C1: Indefinite integral of psC1
        
        PSI_C1_1(b, h, ss)=int(psC1_1,ss);        PSI_C1_2(b, h, ss)=int(psC1_2,ss);
        PSI_C1_3(b, h, ss)=int(psC1_3,ss);        PSI_C1_4(b, h, ss)=int(psC1_4,ss);


% Considering the conditions defined in Eqs. (7.44) and (7.45)

        mat_A=[ PSI_Uy_1(b, h, h/2)                                           -1;
                int((pzTx_1*PSI_Uy_1),ss,-h/2,h/2)     int((pzTx_2),ss,-b/2,b/2)];
        
        mat_B=[ -((PSI_C1_1(b, h, h/2))-(PSI_C1_2(b, h, -b/2)));
                -(int((pzTx_1*PSI_C1_1),ss,-h/2,h/2)+int((pzTx_2*PSI_C1_2),ss,-b/2,b/2))];
            
% Determining the unknown coefficients

        mat_W1z=(mat_A)\(mat_B);
        

%% Closed-Form Expression of pzW1 (see Eq. (7.42))

% B1_star: scaling constant of mode W1

        Coeff_W1z=formula(mat_W1z);

        B1_star=(-2/100)/(Coeff_W1z(1)*(PSI_Uy_1(b, h, h/2))+(PSI_C1_1(b, h, h/2)));

        pzW1_1(b, h, ss)= (B1_star)*(Coeff_W1z(1)*(PSI_Uy_1)+(PSI_C1_1));        pzW1_2(b, h, ss)= (B1_star)*((PSI_C1_2)+Coeff_W1z(2));
        pzW1_3(b, h, ss)=-(B1_star)*(Coeff_W1z(1)*(PSI_Uy_1)+(PSI_C1_1));        pzW1_4(b, h, ss)=-(B1_star)*((PSI_C1_2)+Coeff_W1z(2));


%% Save the resulting pzW1
                        
        save Sec_Shape_Func_W1.mat  pzW1_1  pzW1_2  pzW1_3  pzW1_4
        
        
        
        
        
        
        