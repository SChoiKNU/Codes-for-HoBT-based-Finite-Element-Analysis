function [pnTz,psTz,pzTz,pnC0,psC0,pzC0,pnW0,psW0,pzW0,pnC1,psC1,pzC1,pnW1,psW1,pzW1]=HoBT_Shapefunc(ss,ed_num)

%  b_val: value of the box beam section width
%  h_val: value of the box beam section height
% ed_num: given edge number
%     ss: given s coordinate on the considered edge

load Sec_Shape_Func_b50_h75.mat

b_val=0.050;
h_val=0.075;

switch(ed_num)

% edge 1

    case 1

        pnTz= -ss;
        psTz= b_val/2;
        pzTz= 0;
        
        pnC0= given_pnC0_1(ss);
        psC0= given_psC0_1(ss);
        pzC0= 0;
        
        pnW0= 0;
        psW0= 0;
        pzW0= given_pzW0_1(ss);
        
        pnC1=given_pnC1_1(ss);
        psC1=given_psC1_1(ss);
        pzC1=0;

        pnW1=0;
        psW1=0;
        pzW1=given_pzW1_1(ss);

% edge 2
        
    case 2
        
        pnTz= -ss;
        psTz= h_val/2;
        pzTz= 0;
        
        pnC0= given_pnC0_2(ss);
        psC0= given_psC0_2(ss);
        pzC0= 0;
        
        pnW0= 0;
        psW0= 0;
        pzW0= given_pzW0_2(ss);
        
        pnC1=given_pnC1_2(ss);
        psC1=given_psC1_2(ss);
        pzC1=0;

        pnW1=0;
        psW1=0;
        pzW1=given_pzW1_2(ss);

% edge 3
        
    case 3
        
        pnTz= -ss;
        psTz= b_val/2;
        pzTz= 0;
        
        pnC0= given_pnC0_3(ss);
        psC0= given_psC0_3(ss);
        pzC0= 0;
        
        pnW0= 0;
        psW0= 0;
        pzW0= given_pzW0_3(ss);
        
        pnC1=given_pnC1_3(ss);
        psC1=given_psC1_3(ss);
        pzC1=0;

        pnW1=0;
        psW1=0;
        pzW1=given_pzW1_3(ss);

% edge 4
        
    case 4
        
        pnTz= -ss;
        psTz= h_val/2;
        pzTz= 0;
        
        pnC0= given_pnC0_4(ss);
        psC0= given_psC0_4(ss);
        pzC0= 0;
        
        pnW0= 0;
        psW0= 0;
        pzW0= given_pzW0_4(ss);
        
        pnC1=given_pnC1_4(ss);
        psC1=given_psC1_4(ss);
        pzC1=0;

        pnW1=0;
        psW1=0;
        pzW1=given_pzW1_4(ss);
        
end
end
    