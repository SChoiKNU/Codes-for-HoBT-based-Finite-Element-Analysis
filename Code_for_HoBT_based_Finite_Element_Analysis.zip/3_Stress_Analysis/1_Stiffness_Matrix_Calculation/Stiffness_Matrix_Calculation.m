%% Stiffness Matrix Calculation Code

% This code considers the numerical problem shown in Figure 6.8
% Thus, this code only considers sectional modes shown under extension, especially Uz, C1, W1, C2, W2, C3, W3, C4, W4, C5, W5 (i.e., N1=5, N2=0)

%  ss: s coordinate of the local coordinate system (z, n, s)
%  nn: n coordinate of the local coordinate system (z, n, s)
% csy: z-directional natural coordinate (-1 <= csy <= 1)

% Uz: Rigid-body translation along the z direction
% C1: 1st-order unconstrained distortion mode
% W1: 1st-order warping mode

% psC1: s-directional shape function of C1
% psC1_j: psC1 for edge j (j=1, 2, 3, 4)
% pnC1: n-directional shape function of C1
% pnC1_j: pnC1 for edge j (j=1, 2, 3, 4)
% -> The same notations are also used for other modes (e.g., Uz, C1, W1...).

%%
clearvars;
clc;

        syms ss nn csy
      
%% Given Parameter Values

%  b_val: value of the box beam section width
%  h_val: value of the box beam section height
%  t_val: value of the box beam section thickness
%  E: Young's modulus
%  v: Poisson's ratio
%  G: Shear modulus
%  L: Length of the box beam member
%  n: number of discretization
%  ele_L: Length of the box beam element

b_val=0.050;     
h_val=0.075;     
t_val=0.002;

E=200*10^(9);
v=0.3;
E_1=E/(1-v^2);
G=E/(2*(1+v));

L=1;
n=640;

ele_L=L/n;

%% Define Sectional Shape Functions for the box beam with (b_val, h_val)

load Sec_Shape_Func_b50_h75.mat

    % Edge 1 Section-Shape Functions
        
        pnUz_1=0;
        psUz_1=0;
        pzUz_1=1;
        
        pnC1_1=given_pnC1_1;
        psC1_1=given_psC1_1;
        pzC1_1=0;

        pnW1_1=0;
        psW1_1=0;
        pzW1_1=given_pzW1_1;
        
        pnC2_1=given_pnC2_1;
        psC2_1=given_psC2_1;
        pzC2_1=0;

        pnW2_1=0;
        psW2_1=0;
        pzW2_1=given_pzW2_1;
        
        pnC3_1=given_pnC3_1;
        psC3_1=given_psC3_1;
        pzC3_1=0;

        pnW3_1=0;
        psW3_1=0;
        pzW3_1=given_pzW3_1;
        
        pnC4_1=given_pnC4_1;
        psC4_1=given_psC4_1;
        pzC4_1=0;

        pnW4_1=0;
        psW4_1=0;
        pzW4_1=given_pzW4_1;
        
        pnC5_1=given_pnC5_1;
        psC5_1=given_psC5_1;
        pzC5_1=0;

        pnW5_1=0;
        psW5_1=0;
        pzW5_1=given_pzW5_1;
        
    % Edge 2 Section-Shape Functions
        
        pnUz_2=0;
        psUz_2=0;
        pzUz_2=1;
        
        pnC1_2=given_pnC1_2;
        psC1_2=given_psC1_2;
        pzC1_2=0;
        
        pnW1_2=0;
        psW1_2=0;
        pzW1_2=given_pzW1_2;

        pnC2_2=given_pnC2_2;
        psC2_2=given_psC2_2;
        pzC2_2=0;
        
        pnW2_2=0;
        psW2_2=0;
        pzW2_2=given_pzW2_2;

        pnC3_2=given_pnC3_2;
        psC3_2=given_psC3_2;
        pzC3_2=0;
        
        pnW3_2=0;
        psW3_2=0;
        pzW3_2=given_pzW3_2;

        pnC4_2=given_pnC4_2;
        psC4_2=given_psC4_2;
        pzC4_2=0;
        
        pnW4_2=0;
        psW4_2=0;
        pzW4_2=given_pzW4_2;

        pnC5_2=given_pnC5_2;
        psC5_2=given_psC5_2;
        pzC5_2=0;
        
        pnW5_2=0;
        psW5_2=0;
        pzW5_2=given_pzW5_2;

    % Edge 3 Section-Shape Functions
        
        pnUz_3=0;
        psUz_3=0;
        pzUz_3=1;

        pnC1_3=given_pnC1_3;
        psC1_3=given_psC1_3;
        pzC1_3=0;
        
        pnW1_3=0;
        psW1_3=0;
        pzW1_3=given_pzW1_3;

        pnC2_3=given_pnC2_3;
        psC2_3=given_psC2_3;
        pzC2_3=0;
        
        pnW2_3=0;
        psW2_3=0;
        pzW2_3=given_pzW2_3;

        pnC3_3=given_pnC3_3;
        psC3_3=given_psC3_3;
        pzC3_3=0;
        
        pnW3_3=0;
        psW3_3=0;
        pzW3_3=given_pzW3_3;

        pnC4_3=given_pnC4_3;
        psC4_3=given_psC4_3;
        pzC4_3=0;
        
        pnW4_3=0;
        psW4_3=0;
        pzW4_3=given_pzW4_3;

        pnC5_3=given_pnC5_3;
        psC5_3=given_psC5_3;
        pzC5_3=0;
        
        pnW5_3=0;
        psW5_3=0;
        pzW5_3=given_pzW5_3;

    % Edge 4 Section-Shape Functions
        
        pnUz_4=0;
        psUz_4=0;
        pzUz_4=1;
        
        pnC1_4=given_pnC1_4;
        psC1_4=given_psC1_4;
        pzC1_4=0;  
    
        pnW1_4=0;
        psW1_4=0;
        pzW1_4=given_pzW1_4;
        
        pnC2_4=given_pnC2_4;
        psC2_4=given_psC2_4;
        pzC2_4=0;  
    
        pnW2_4=0;
        psW2_4=0;
        pzW2_4=given_pzW2_4;
        
        pnC3_4=given_pnC3_4;
        psC3_4=given_psC3_4;
        pzC3_4=0;  
    
        pnW3_4=0;
        psW3_4=0;
        pzW3_4=given_pzW3_4;
        
        pnC4_4=given_pnC4_4;
        psC4_4=given_psC4_4;
        pzC4_4=0;  
    
        pnW4_4=0;
        psW4_4=0;
        pzW4_4=given_pzW4_4;
        
        pnC5_4=given_pnC5_4;
        psC5_4=given_psC5_4;
        pzC5_4=0;  
    
        pnW5_4=0;
        psW5_4=0;
        pzW5_4=given_pzW5_4;
        

%% Define Interpolation Functions
% Linear interpolation functions:  (1-csy)/2, (1+csy)/2
% Kinematic variables per node: {Uz, C1, W1, C2, W2, C3, W3, C4, W4, C5, W5}

% mat_H: Interpolation Function Matrix N (see Eq. (3.21))
        
        mat_H=[(1-csy)/2 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0 0 0 0 0 0;
               0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0 0 0 0 0;
               0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0 0 0 0;
               0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0 0 0;
               0 0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0 0;
               0 0 0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0 0;
               0 0 0 0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0 0;
               0 0 0 0 0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0 0;
               0 0 0 0 0 0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0 0;
               0 0 0 0 0 0 0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 (1+csy)/2 0;
               0 0 0 0 0 0 0 0 0 0 (1-csy)/2 0 0 0 0 0 0 0 0 0 0 (1+csy)/2];


%% Define Displacement Field (see Eq. (6.3))        
% dis_s_j: s-directional displacement at edge j (j=1, 2, 3, 4)
% dis_z_j: z-directional displacement at edge j (j=1, 2, 3, 4)
    
        dis_s_1=[psUz_1 psC1_1 psW1_1 psC2_1 psW2_1 psC3_1 psW3_1 psC4_1 psW4_1 psC5_1 psW5_1]*mat_H;
        dis_z_1=[pzUz_1 pzC1_1 pzW1_1 pzC2_1 pzW2_1 pzC3_1 pzW3_1 pzC4_1 pzW4_1 pzC5_1 pzW5_1]*mat_H;

        dis_s_2=[psUz_2 psC1_2 psW1_2 psC2_2 psW2_2 psC3_2 psW3_2 psC4_2 psW4_2 psC5_2 psW5_2]*mat_H;
        dis_z_2=[pzUz_2 pzC1_2 pzW1_2 pzC2_2 pzW2_2 pzC3_2 pzW3_2 pzC4_2 pzW4_2 pzC5_2 pzW5_2]*mat_H;
        
        dis_s_3=[psUz_3 psC1_3 psW1_3 psC2_3 psW2_3 psC3_3 psW3_3 psC4_3 psW4_3 psC5_3 psW5_3]*mat_H;
        dis_z_3=[pzUz_3 pzC1_3 pzW1_3 pzC2_3 pzW2_3 pzC3_3 pzW3_3 pzC4_3 pzW4_3 pzC5_3 pzW5_3]*mat_H;
        
        dis_s_4=[psUz_4 psC1_4 psW1_4 psC2_4 psW2_4 psC3_4 psW3_4 psC4_4 psW4_4 psC5_4 psW5_4]*mat_H;
        dis_z_4=[pzUz_4 pzC1_4 pzW1_4 pzC2_4 pzW2_4 pzC3_4 pzW3_4 pzC4_4 pzW4_4 pzC5_4 pzW5_4]*mat_H;
        

%% Define Strain Field (see Eq. (6.4))        
% str_zz_j: z-directional normal strain at edge j (j=1, 2, 3, 4)
% str_ss_j: s-directional normal strain at edge j (j=1, 2, 3, 4)
% str_sz_j: shear strain at edge j (j=1, 2, 3, 4)

        str_zz_1=diff(dis_z_1,csy)*(2/ele_L);
        str_ss_1=diff(dis_s_1,ss);
        str_sz_1=diff(dis_z_1,ss)+diff(dis_s_1,csy)*(2/ele_L);

        str_zz_2=diff(dis_z_2,csy)*(2/ele_L);
        str_ss_2=diff(dis_s_2,ss);
        str_sz_2=diff(dis_z_2,ss)+diff(dis_s_2,csy)*(2/ele_L);

        str_zz_3=diff(dis_z_3,csy)*(2/ele_L);
        str_ss_3=diff(dis_s_3,ss);
        str_sz_3=diff(dis_z_3,ss)+diff(dis_s_3,csy)*(2/ele_L);

        str_zz_4=diff(dis_z_4,csy)*(2/ele_L);
        str_ss_4=diff(dis_s_4,ss);
        str_sz_4=diff(dis_z_4,ss)+diff(dis_s_4,csy)*(2/ele_L);


%% Define Constitutive Relations (see Eq. (6.5))

        mat_C=[E_1      E_1*v    0;
               E_1*v    E_1      0;
               0        0        G];


%% Calculate Stiffness Matrix (see Eqs. (3.24) and (6.7))       
% mat_K_j: local stiffness matrix K calculated at edge j (j=1, 2, 3, 4)

        mat_B_1=[str_zz_1;
                 str_ss_1;
                 str_sz_1];
                            
        mat_B_2=[str_zz_2;
                 str_ss_2;
                 str_sz_2];
               
        mat_B_3=[str_zz_3;
                 str_ss_3;
                 str_sz_3];
        
        mat_B_4=[str_zz_4;
                 str_ss_4;
                 str_sz_4];

               
        mat_K_1=(mat_B_1)'*mat_C*mat_B_1;

        mat_K_2=(mat_B_2)'*mat_C*mat_B_2;
  
        mat_K_3=(mat_B_3)'*mat_C*mat_B_3;
        
        mat_K_4=(mat_B_4)'*mat_C*mat_B_4;

        
        mat_K_13=mat_K_1+mat_K_3;

        mat_K_24=mat_K_2+mat_K_4;


% Volume integration to obtain the element stiffness matrix (see Eq. (3.27)) 
          
        local_K_13=zeros(22,22);
        local_K_24=zeros(22,22);
        
        
        for ii=1:22
            for jj=1:22
                local_K_13(ii,jj)=int(int(int(mat_K_13(ii,jj),ss,-(h_val/2),(h_val/2)),nn,-(t_val/2),t_val/2),csy,-1,1)*(ele_L/2);
            end
        end
        
        for ii=1:22
            for jj=1:22
                local_K_24(ii,jj)=int(int(int(mat_K_24(ii,jj),ss,-(b_val/2),(b_val/2)),nn,-(t_val/2),t_val/2),csy,-1,1)*(ele_L/2);
            end
        end        


% local_K: The resulting element stiffness matrix

        local_K=local_K_13+local_K_24;
        
        save K_matrix_b50_h75.mat local_K
        

% matrix_Bj: Matrix to calculate strain at (ss, csy) of edge j 

        matrix_B1(ss,csy)=mat_B_1;        matrix_B2(ss,csy)=mat_B_2;
        matrix_B3(ss,csy)=mat_B_3;        matrix_B4(ss,csy)=mat_B_4;
        
        save B_matrix_b50_h75.mat matrix_B1 matrix_B2 matrix_B3 matrix_B4

        
        
        
        

        